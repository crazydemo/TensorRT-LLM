# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
"""Preserve full upstream dryrun decisions and apply the residual compatibility gate."""
import json
import os
import subprocess
import tarfile
import io
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from cbts.command import dryrun
from cbts.command.report_decision import _case_counts, _is_scheduled_stage, _stage_group
from cbts.blocks import YAMLIndex, block_matches_stage, parse_stages_from_groovy

root = Path(__file__).resolve().parent
repo = root / 'repo'
manifest = json.loads((root / 'manifest.json').read_text())
coverage = json.loads((root / 'latest-coverage.json').read_text())
out = root / 'latest'
out.mkdir(exist_ok=True)
original_run = dryrun._run_cbts

def metrics(decision, snapshot):
    stages = parse_stages_from_groovy(snapshot / 'jenkins/L0_Test.groovy', include_post_merge=True)
    index = YAMLIndex.load(snapshot / dryrun.TEST_DB_REL)
    groups = {}
    for name, stage in stages.items():
        if _is_scheduled_stage(name, 'pre_merge', False):
            groups.setdefault(_stage_group(name), {})[name] = stage
    affected = set(decision.get('affected_stages') or [])
    counts = decision.get('affected_stage_test_counts') or {}
    families = {}
    for group, members in groups.items():
        stage = next(iter(members.values()))
        total = sum(len(b.tests) for b in index.blocks if b.yaml_stem == stage.yaml_stem and block_matches_stage(b, stage))
        if decision.get('scope') is None:
            kept = total
        elif affected & members.keys():
            candidates = [counts[n] for n in members if n in counts]
            kept = max(candidates) if candidates else total
        elif ('PackageSanityCheck' in group and decision.get('sanity_required', True)) or ('PerfSanity' in group and decision.get('perfsanity_required', True)):
            kept = total
        else:
            kept = 0
        families[group] = dict(total=total, kept=kept, skipped=total-kept)
    kept = sum(v['kept'] for v in families.values())
    total = sum(v['total'] for v in families.values())
    if decision.get('scope') is not None:
        assert (kept, total) == _case_counts(decision, 'pre_merge', str(snapshot)), (kept, total)
    assert total > 0 and 0 <= kept <= total
    return dict(total=total, kept=kept, skipped=total-kept, families=families)

def wrapped_run(payload, test_db, groovy, snapshot, coverage_db=None):
    sha = dryrun._git(snapshot, 'rev-parse', 'HEAD').stdout.strip()
    sample = next(s for s in manifest['samples'] if s['sha'] == sha)
    dest = out / ('pr-' + sample['pr'])
    dest.mkdir(exist_ok=True)
    (dest / 'input.json').write_text(json.dumps(payload, indent=2))
    result = original_run(payload, test_db, groovy, snapshot, coverage_db)
    (dest / 'candidate-metrics.json').write_text(json.dumps(metrics(result, snapshot), indent=2))
    return result

dryrun._run_cbts = wrapped_run

def compatibility(sample, residual):
    if not residual:
        return dict(status='not_attempted', conflicts=[])
    sha = sample['sha']
    base = dryrun._git(repo, 'rev-parse', sha+'^').stdout.strip()
    commit = dryrun._git(repo, '-c', 'user.name=CBTS', '-c', 'user.email=cbts@nvidia.com',
                         'commit-tree', sha+'^{tree}', '-p', base, '-m', 'CBTS fixed83 synthetic patch compatibility').stdout.strip()
    actual_base = dryrun._git(repo, 'merge-base', coverage['commit'], commit).stdout.strip()
    assert actual_base == base
    result = subprocess.run(['git', 'merge-tree', '--write-tree', '--name-only', '-z', coverage['commit'], commit], cwd=repo, capture_output=True)
    assert result.returncode in (0, 1), result.stderr
    fields = result.stdout.split(b'\0')
    conflicts = []
    if result.returncode == 1:
        for field in fields[1:]:
            if not field:
                break
            conflicts.append(field.decode())
    relevant = sorted(set(residual) & set(conflicts))
    return dict(status='conflict' if relevant else 'clean', conflicts=conflicts, residual_conflicts=relevant,
                method='git merge-tree with synthetic PR tree parented at sample parent; identical three-way inputs to cherry-pick', base=base)

def replay(sample):
    dest = out / ('pr-' + sample['pr'])
    saved = dest / 'result.json'
    if saved.exists():
        return json.loads(saved.read_text())
    row = dryrun._replay_one(repo, sample['sha'], out, False, str(root/'coverage'/'cbts_touchmap.sqlite'))
    candidate = row[4]
    assert '_error' not in candidate, candidate
    candidate_metrics = json.loads((dest / 'candidate-metrics.json').read_text())
    compat = (compatibility(sample, candidate.get('coverage_residual_files') or [])
              if candidate.get('scope') == 'coverage'
              else dict(status='not_needed_tier1' if candidate.get('scope') else 'not_needed_fallback', conflicts=[]))
    (dest / 'candidate.json').write_text(json.dumps(candidate, indent=2))
    eligible = bool(candidate.get('scope')) and (candidate['scope'] != 'coverage' or compat['status'] == 'clean')
    effective_metrics = candidate_metrics if eligible else dict(candidate_metrics, kept=candidate_metrics['total'], skipped=0,
        families={k: dict(v, kept=v['total'], skipped=0) for k,v in candidate_metrics['families'].items()})
    files = dryrun._list_changed_files(repo, sample['sha'])
    result = dict(sample=sample, core_python=any(p.startswith('tensorrt_llm/') and p.endswith('.py') for p in files),
        candidate=candidate, compatibility=compat, eligible_hit=eligible,
        candidate_metrics=candidate_metrics, effective_metrics=effective_metrics)
    saved.write_text(json.dumps(result, indent=2))
    print(sample['pr'], candidate.get('scope'), compat['status'], 'skipped', effective_metrics['skipped'], flush=True)
    return result

with ThreadPoolExecutor(max_workers=4) as pool:
    results = list(pool.map(replay, manifest['samples']))
(out / 'results.json').write_text(json.dumps(results, indent=2))
assert len(results) == 82
assert not any('errored' in (r['candidate'].get('coverage_decline_reason') or '') for r in results)

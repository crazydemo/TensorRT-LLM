# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Read-only accessor for a compact merged CBTS touch DB (`cbts_touchmap.sqlite`).

Implements the TOUCH_DB_CONTRACT.md queries. Two real-data details:
  - the `test` column is `<stage>/<nodeid>` (stage-prefixed);
  - unit tests are recorded wrapped as
    `test_unittests.py::test_unittests_v2[<inner>]`, while test-db YAML lists
    the bare `<inner>` entry.
"""

from __future__ import annotations

import re
import sqlite3
from pathlib import Path
from typing import Optional

from cbts.blocks import normalize_test_id
from cbts.coverage.collection.compact_db import canonicalize_path

# A DB test value is `<stage>/<nodeid>`; unit tests wrap the inner entry.
_UNITTEST_WRAP_RE = re.compile(r"::test_unittests_v2\[(?P<inner>.+)\]$")

# Trailing `-<split_id>` of a pytest-split shard name.
_SPLIT_SUFFIX_RE = re.compile(r"-\d+$")

# Completeness-heuristic constants consumed by `untrusted_tests()`.
_WORKER_SENTINEL = "tensorrt_llm/_torch/pyexecutor/py_executor.py"
_LAUNCH_MARKERS: tuple[tuple[str, str], ...] = (
    ("tensorrt_llm/llmapi/llm.py", "generate"),
    ("tensorrt_llm/executor/executor.py", "GenerationExecutor.generate"),
)
_SERVING_PATH_MARKERS: tuple[str, ...] = ("disaggregated/",)
# Stage-name markers whose GPU worker is uninstrumented, so capture is partial.
_UNTRUSTED_STAGE_MARKERS: tuple[str, ...] = ("-Ray-",)
_MIN_FUNCS = 30
_SCHEMA_VERSION = "5"
_STORAGE_SCHEMA = "compact-v1"

_QUALIFIED_TEST_SQL = (
    "CASE WHEN case_stage.test='' THEN '' "
    "WHEN stage.name='' THEN case_stage.test "
    "ELSE stage.name || '/' || case_stage.test END"
)


def canon(path: str) -> str:
    """Use collection's file identity, preserving repository-relative paths."""
    return canonicalize_path(path)


def split_stage(test: str) -> tuple[str, str]:
    """Split a DB `test` value `<stage>/<nodeid>` into `(stage, nodeid)`; `("", test)` if no `/`."""
    stage, sep, nodeid = test.partition("/")
    return (stage, nodeid) if sep else ("", test)


def stage_family(stage: str) -> str:
    """Collapse a pytest-split shard name to its family (`A10-PyTorch-2` -> `A10-PyTorch`)."""
    return _SPLIT_SUFFIX_RE.sub("", stage)


def unwrap_unittest(nodeid: str) -> Optional[str]:
    """Return the inner `unittest/...` entry of a wrapped unittest nodeid, else None.

    `test_unittests.py::test_unittests_v2[unittest/x.py -m "part0"]`
        -> `unittest/x.py -m "part0"`
    """
    m = _UNITTEST_WRAP_RE.search(nodeid)
    return m.group("inner") if m else None


def db_key(entry: str) -> Optional[str]:
    """Map a test-db YAML `tests:` entry to the DB nodeid form, or None if not 1:1.

    Unit tests wrap as `test_unittests.py::test_unittests_v2[<inner>]`; a `-k`
    keyword entry expands to many nodeids (no single DB key) -> None.
    """
    e = normalize_test_id(entry)
    if e.startswith("unittest/"):
        return f"test_unittests.py::test_unittests_v2[{e}]"
    if " -k " in e:
        return None
    return e


class TouchDB:
    """Read-only view over a merged `cbts_touchmap.sqlite`."""

    def __init__(self, conn: sqlite3.Connection) -> None:
        self._conn = conn

    @classmethod
    def open(cls, sqlite_path: Path | str) -> "TouchDB":
        """Open the DB read-only (`mode=ro`) and verify the compact schema."""
        path = Path(sqlite_path).resolve()
        uri = f"file:{path}?mode=ro"
        try:
            conn = sqlite3.connect(uri, uri=True)
        except sqlite3.Error as exc:
            raise ValueError(f"{path}: unable to open compact touch database: {exc}") from exc

        try:
            touch_cols = {row[1] for row in conn.execute("PRAGMA table_info(touch)")}
            row_cols = {row[1] for row in conn.execute("PRAGMA table_info(touch_rows)")}
            test_meta_cols = {row[1] for row in conn.execute("PRAGMA table_info(test_case_meta)")}
            metadata = dict(conn.execute("SELECT key, value FROM meta"))
        except sqlite3.Error as exc:
            conn.close()
            raise ValueError(f"{path}: unable to read compact touch database: {exc}") from exc
        if (
            not {"case_stage_id", "symbol_id"} <= touch_cols
            or not {
                "test",
                "file",
                "qualname",
                "stage",
            }
            <= row_cols
            or not {
                "test",
                "stage",
                "outcome",
                "tainted",
            }
            <= test_meta_cols
            or metadata.get("schema_version") != _SCHEMA_VERSION
            or metadata.get("storage_schema") != _STORAGE_SCHEMA
        ):
            conn.close()
            raise ValueError(
                "unexpected compact touch schema, "
                f"touch_columns={sorted(touch_cols)}, row_columns={sorted(row_cols)}, "
                f"test_meta_columns={sorted(test_meta_cols)}, "
                f"schema_version={metadata.get('schema_version')}, "
                f"storage_schema={metadata.get('storage_schema')}"
            )
        return cls(conn)

    def close(self) -> None:
        self._conn.close()

    def __enter__(self) -> "TouchDB":
        return self

    def __exit__(self, *_exc) -> None:
        self.close()

    # -- meta (every key optional; read with a default) --

    def meta(self, key: str, default: Optional[str] = None) -> Optional[str]:
        try:
            row = self._conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
        except sqlite3.OperationalError:
            return default
        return row[0] if row is not None else default

    def schema_version(self) -> Optional[str]:
        return self.meta("schema_version")

    def collection_commit(self) -> Optional[str]:
        """Commit the DB was collected at, or None if not recorded."""
        return self.meta("commit") or self.meta("collection_commit")

    # -- reverse lookup (the core of selection); always `test != ''` --

    def tests_touching_file(self, file: str) -> set[str]:
        """Stage-prefixed tests that entered any function in `file` (file-level)."""
        return {
            row[0]
            for row in self._conn.execute(
                f"SELECT DISTINCT {_QUALIFIED_TEST_SQL} "
                "FROM file "
                "JOIN symbol ON symbol.file_id=file.id "
                "JOIN touch ON touch.symbol_id=symbol.id "
                "JOIN case_stage ON case_stage.id=touch.case_stage_id "
                "JOIN stage ON stage.id=case_stage.stage_id "
                "WHERE file.path=? AND case_stage.test!=''",
                (file,),
            )
        }

    def tests_touching_func(self, file: str, qualname: str) -> set[str]:
        """Stage-prefixed tests that entered `qualname` in `file` (function-level)."""
        return {
            row[0]
            for row in self._conn.execute(
                f"SELECT DISTINCT {_QUALIFIED_TEST_SQL} "
                "FROM file "
                "JOIN symbol ON symbol.file_id=file.id "
                "JOIN touch ON touch.symbol_id=symbol.id "
                "JOIN case_stage ON case_stage.id=touch.case_stage_id "
                "JOIN stage ON stage.id=case_stage.stage_id "
                "WHERE file.path=? AND symbol.qualname=? AND case_stage.test!=''",
                (file, qualname),
            )
        }

    def file_has_touch_rows(self, file: str) -> bool:
        """True iff any instrumented test entered a function in `file`."""
        row = self._conn.execute(
            "SELECT 1 "
            "FROM file "
            "JOIN symbol ON symbol.file_id=file.id "
            "JOIN touch ON touch.symbol_id=symbol.id "
            "JOIN case_stage ON case_stage.id=touch.case_stage_id "
            "WHERE file.path=? AND case_stage.test!='' LIMIT 1",
            (file,),
        ).fetchone()
        return row is not None

    # -- universe / per-stage --

    def known_tests(self) -> set[str]:
        """Every stage-prefixed test with coverage data."""
        return {
            row[0]
            for row in self._conn.execute(
                f"SELECT DISTINCT {_QUALIFIED_TEST_SQL} "
                "FROM touch JOIN case_stage ON case_stage.id=touch.case_stage_id "
                "JOIN stage ON stage.id=case_stage.stage_id "
                "WHERE case_stage.test!=''"
            )
        }

    def per_test_footprint(self) -> dict[str, int]:
        """`{test -> functions entered}` over all stage-prefixed tests."""
        return {
            row[0]: row[1]
            for row in self._conn.execute(
                f"SELECT {_QUALIFIED_TEST_SQL}, COUNT(*) "
                "FROM touch JOIN case_stage ON case_stage.id=touch.case_stage_id "
                "JOIN stage ON stage.id=case_stage.stage_id "
                "WHERE case_stage.test!='' GROUP BY case_stage.id"
            )
        }

    def instrumented_stages(self) -> set[str]:
        """Stage names the DB has data for — the stages coverage may narrow."""
        return {stage for stage, _ in map(split_stage, self.known_tests()) if stage}

    def known_by_stage(self) -> dict[str, set[str]]:
        """`{stage -> {bare nodeid, ...}}` over all known tests."""
        out: dict[str, set[str]] = {}
        for test in self.known_tests():
            stage, nodeid = split_stage(test)
            if stage:
                out.setdefault(stage, set()).add(nodeid)
        return out

    def known_by_family(self) -> dict[str, set[str]]:
        """`{stage family -> {bare nodeid, ...}}` — a stage's shards unioned."""
        out: dict[str, set[str]] = {}
        for test in self.known_tests():
            stage, nodeid = split_stage(test)
            if stage:
                out.setdefault(stage_family(stage), set()).add(nodeid)
        return out

    # -- forward lookup (debug / explain-why) --

    def files_touched_by(self, test: str) -> list[tuple[str, str]]:
        """`(file, qualname)` rows for a stage-prefixed `test`."""
        stage, nodeid = split_stage(test)
        predicate = "case_stage.test=?"
        parameters: tuple[str, ...] = (nodeid,)
        if stage:
            predicate += " AND stage.name=?"
            parameters += (stage,)
        return [
            (row[0], row[1])
            for row in self._conn.execute(
                "SELECT file.path, symbol.qualname "
                "FROM case_stage "
                "JOIN stage ON stage.id=case_stage.stage_id "
                "JOIN touch ON touch.case_stage_id=case_stage.id "
                "JOIN symbol ON symbol.id=touch.symbol_id "
                "JOIN file ON file.id=symbol.file_id "
                f"WHERE {predicate}",
                parameters,
            )
        ]

    def incomplete_capture_tests(self) -> set[str]:
        """Tests not safe to skip, for either of two independent reasons.

        Only the latter is actually about capture reliability; ``outcome`` is not, and is
        included here purely because it has the same effect on the skip decision -- a test
        that failed outright still needs to keep running regardless of how trustworthy its
        (possibly perfectly complete) coverage is.

        - ``outcome``: the test did not pass (or has no recorded outcome at all).
        - ``tainted``: a process saved, but the context channel could not confirm it was
          recording against the right test.
        """
        rows = self._conn.execute(
            "SELECT test FROM test_case_meta WHERE test != '' AND "
            "(outcome IS NULL OR outcome != 'passed' OR tainted != 0)"
        )
        # Tests that recorded nothing are not selection candidates.
        return {row[0] for row in rows} & self.known_tests()

    # -- coverage-completeness heuristic --

    def untrusted_tests(
        self,
        worker_file: str,
        launch_markers: tuple[tuple[str, str], ...],
        serving_path_markers: tuple[str, ...],
        min_funcs: int,
        untrusted_stage_markers: tuple[str, ...] = (),
    ) -> set[str]:
        """Tests missing `worker_file` after driving execution, near-empty, or on an untrusted stage."""
        drove_execution: set[str] = set()
        for file, qual_substr in launch_markers:
            drove_execution |= {
                row[0]
                for row in self._conn.execute(
                    f"SELECT DISTINCT {_QUALIFIED_TEST_SQL} "
                    "FROM file "
                    "JOIN symbol ON symbol.file_id=file.id "
                    "JOIN touch ON touch.symbol_id=symbol.id "
                    "JOIN case_stage ON case_stage.id=touch.case_stage_id "
                    "JOIN stage ON stage.id=case_stage.stage_id "
                    "WHERE file.path=? AND symbol.qualname LIKE ? AND case_stage.test!=''",
                    (file, f"%{qual_substr}%"),
                )
            }
        if serving_path_markers:
            drove_execution |= {
                test
                for test in self.known_tests()
                if any(marker in test for marker in serving_path_markers)
            }
        missing_worker = drove_execution - self.tests_touching_file(worker_file)
        tiny = {
            row[0]
            for row in self._conn.execute(
                f"SELECT {_QUALIFIED_TEST_SQL} "
                "FROM touch JOIN case_stage ON case_stage.id=touch.case_stage_id "
                "JOIN stage ON stage.id=case_stage.stage_id "
                "WHERE case_stage.test!='' "
                "GROUP BY case_stage.id HAVING COUNT(*) < ?",
                (min_funcs,),
            )
        }
        on_untrusted_stage: set[str] = set()
        if untrusted_stage_markers:
            on_untrusted_stage = {
                test
                for test in self.known_tests()
                if any(marker in split_stage(test)[0] for marker in untrusted_stage_markers)
            }
        return missing_worker | tiny | on_untrusted_stage | self.incomplete_capture_tests()

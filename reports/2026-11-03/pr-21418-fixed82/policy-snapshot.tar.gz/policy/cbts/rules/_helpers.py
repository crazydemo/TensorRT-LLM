# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Pure-function helpers shared by rules in this package."""

from __future__ import annotations

import re
from typing import Iterable, Iterator

from cbts.blocks import (
    Stage,
    YAMLIndex,
    _entry_target,
    _target_in_filter_subtree,
    block_matches_stage,
)

_HUNK_HEADER_RE = re.compile(r"^@@ -\d+(?:,\d+)? \+(\d+)(?:,\d+)? @@")
_FULL_HUNK_HEADER_RE = re.compile(r"^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@")
_COMMENT_BODY_RE = re.compile(r"^\s*#")


def block_filters_for_stem(
    yaml_index: YAMLIndex, yaml_stem: str
) -> dict[tuple[str, int], dict[str, set[str]]]:
    """Keep every entry in a test-db stem, preserving its options and annotations."""
    filters: dict[tuple[str, int], dict[str, set[str]]] = {}
    for block in yaml_index.blocks:
        if block.yaml_stem != yaml_stem:
            continue
        entries: dict[str, set[str]] = {}
        for entry in block.tests:
            target = _entry_target(entry)
            if target:
                entries.setdefault(target, set()).add(entry)
        filters[(block.yaml_stem, block.block_index)] = entries
    return filters


def strip_noop_diff_lines(diff: str) -> str:
    """Normalize a unified diff so blank- and comment-only edits don't count.

    Blank or comment-only `+/-` lines carry no test-selection meaning for
    CBTS — they can't introduce imports, decorators, test methods, or
    YAML entries. Treating them as real changes causes anchor walk-up
    and stage-select detection to over-fire (e.g. a trailing `+` blank
    line in a method-only diff drops AST scope to module-level and
    forces a file-level anchor fallback).

    Normalization rules:
      - `+` blank / comment-only line → downgrade to context (` `).
        Cursor in `iter_diff_post_line_numbers` still advances, so
        every subsequent line keeps its correct post-image line number.
      - `-` blank / comment-only line → drop entirely. `-` lines never
        advance the post-image cursor, so removal is safe.
      - All real-content `+/-` lines, context lines, hunk headers, and
        file headers are emitted verbatim.

    Hunk header counts (`-A,B +C,D`) are left as-is — CBTS walkers
    don't consume B or D; only `+C` (the post-image start line) is
    read, and that remains correct because we preserve cursor steps
    via the context-downgrade trick.
    """
    out: list[str] = []
    for raw in diff.splitlines(keepends=True):
        body = raw.rstrip("\n").rstrip("\r")
        if not body or body.startswith(("+++", "---", "@@")):
            out.append(raw)
            continue
        sign = body[0]
        rest = body[1:]
        if sign in ("+", "-") and (not rest.strip() or _COMMENT_BODY_RE.match(rest)):
            if sign == "+":
                # downgrade to context: preserves post-image cursor
                out.append(" " + raw[1:])
            # else: drop entirely (no cursor impact)
            continue
        out.append(raw)
    return "".join(out)


def stages_by_yaml_stem(stages: dict[str, Stage]) -> dict[str, list[tuple[str, Stage]]]:
    """Bucket {stage_name: Stage} by yaml_stem for O(stages_in_yaml) lookup."""
    out: dict[str, list[tuple[str, Stage]]] = {}
    for stage_name, stage in stages.items():
        out.setdefault(stage.yaml_stem, []).append((stage_name, stage))
    return out


def is_perf_stem(stem: str) -> bool:
    """Return whether a test-db stem belongs to perf or perf-sanity."""
    return stem == "l0_perf" or "perf_sanity" in stem


def iter_diff_changes(diff: str) -> Iterator[tuple[str, str]]:
    """Yield (sign, body) for every `+`/`-` line; skip headers and context."""
    for line in diff.splitlines():
        if not line or line.startswith(("+++", "---", "@@")):
            continue
        sign = line[0]
        if sign not in ("+", "-"):
            continue
        yield sign, line[1:]


def iter_diff_post_line_numbers(diff: str) -> set[int]:
    """Post-PR line numbers touched by non-blank, non-comment `+` or `-` lines.

    `+` lines mark their own line; `-` lines anchor at the next post-PR
    line. Hunk headers reset the cursor; context lines advance it.
    """
    out: set[int] = set()
    new_line = 0
    for line in strip_noop_diff_lines(diff).splitlines():
        m = _HUNK_HEADER_RE.match(line)
        if m is not None:
            new_line = int(m.group(1))
            continue
        if not line or line.startswith(("+++", "---")):
            continue
        sign = line[0]
        if sign == "+":
            out.add(new_line)
            new_line += 1
        elif sign == "-":
            out.add(new_line)
        else:
            new_line += 1
    return out


def iter_diff_deleted_post_lines(diff: str) -> dict[int, list[str]]:
    """Return non-blank, non-comment deleted lines grouped by post-image anchor."""
    out: dict[int, list[str]] = {}
    new_line = 0
    for line in strip_noop_diff_lines(diff).splitlines():
        m = _HUNK_HEADER_RE.match(line)
        if m is not None:
            new_line = int(m.group(1))
            continue
        if not line or line.startswith(("+++", "---")):
            continue
        sign = line[0]
        if sign == "-":
            out.setdefault(new_line, []).append(line[1:])
        elif sign in (" ", "+"):
            new_line += 1
    return out


def reconstruct_diff_pre_image(post_source: str, diff: str) -> str | None:
    """Reverse a verified unified diff to recover the complete pre-image.

    Every hunk's context and added lines must exactly match ``post_source``.
    Returning ``None`` on malformed or mismatched input keeps callers from
    deriving static facts from a guessed pre-image.
    """
    hunks: list[tuple[int, int, list[str], list[str]]] = []
    current: tuple[int, int, int, list[str], list[str]] | None = None

    def finish_hunk() -> bool:
        nonlocal current
        if current is None:
            return True
        old_count, new_start, new_count, pre_lines, post_lines = current
        if len(pre_lines) != old_count or len(post_lines) != new_count:
            return False
        hunks.append((new_start, new_count, pre_lines, post_lines))
        current = None
        return True

    for line in diff.splitlines():
        match = _FULL_HUNK_HEADER_RE.match(line)
        if match is not None:
            if not finish_hunk():
                return None
            old_count = int(match.group(2) or 1)
            new_start = int(match.group(3))
            new_count = int(match.group(4) or 1)
            current = (old_count, new_start, new_count, [], [])
            continue
        if current is None:
            continue
        if line.startswith("\\ No newline at end of file"):
            continue
        if not line or line[0] not in (" ", "+", "-"):
            if not finish_hunk():
                return None
            continue
        sign, body = line[0], line[1:]
        if sign != "+":
            current[3].append(body)
        if sign != "-":
            current[4].append(body)
    if not finish_hunk() or not hunks:
        return None

    post_lines = post_source.splitlines()
    pre_lines: list[str] = []
    cursor = 0
    for new_start, new_count, hunk_pre, hunk_post in hunks:
        start = new_start if new_count == 0 else new_start - 1
        if start < cursor or post_lines[start : start + new_count] != hunk_post:
            return None
        pre_lines.extend(post_lines[cursor:start])
        pre_lines.extend(hunk_pre)
        cursor = start + new_count
    pre_lines.extend(post_lines[cursor:])
    pre_source = "\n".join(pre_lines)
    if pre_lines and post_source.endswith(("\n", "\r")):
        pre_source += "\n"
    return pre_source


def iter_diff_added_post_line_numbers(diff: str) -> set[int]:
    """Post-PR line numbers (1-indexed) touched by `+` lines only.

    Unlike `iter_diff_post_line_numbers`, `-` lines are excluded rather
    than anchored to the next surviving line. Callers that read meaning
    from the post-image (YAML section, AST scope) need this: a deleted
    line's anchor can land in a different section than the one it was
    deleted from.
    """
    out: set[int] = set()
    new_line = 0
    for line in diff.splitlines():
        m = _HUNK_HEADER_RE.match(line)
        if m is not None:
            new_line = int(m.group(1))
            continue
        if not line or line.startswith(("+++", "---")):
            continue
        sign = line[0]
        if sign == "+":
            out.add(new_line)
            new_line += 1
        elif sign != "-":
            new_line += 1
    return out


def iter_diff_pre_image(diff: str) -> Iterator[tuple[str, str]]:
    """Yield `(sign, body)` for the pre-image content of each hunk.

    Context and `-` lines together reconstruct what the file looked like
    before the change, in order, within each hunk. `sign` is `-` for
    deleted lines and ` ` for context. A `@@` hunk header yields
    `("@", "")` so callers can reset any positional state they track —
    pre-image continuity does not hold across hunk boundaries.

    Blank/comment-only additions may appear as context despite being absent before the change.
    Line numbers are deliberately not reported: `strip_noop_diff_lines`
    drops blank / comment-only `-` lines, which shifts every later
    pre-image line number. Callers must derive meaning from the
    in-hunk ordering instead.
    """
    for line in diff.splitlines():
        if line.startswith("@@"):
            yield "@", ""
            continue
        if not line or line.startswith(("+++", "---")):
            continue
        sign = line[0]
        if sign in ("-", " "):
            yield sign, line[1:]


def lookup_ids_into_block_filters(
    yaml_index: YAMLIndex,
    test_ids: Iterable[str],
) -> tuple[dict[tuple[str, int], dict[str, set[str]]], list[str]]:
    """Resolve test ids via `find_match_for_waive`; return (block_filters, misses).

    Each id is added to its matched level's identifier set per affected
    block, so `write_filtered_test_db`'s `-k` keyword guard re-checks
    each entry against the original test ids.
    """
    block_filters: dict[tuple[str, int], dict[str, set[str]]] = {}
    misses: list[str] = []
    for tid in test_ids:
        match = yaml_index.find_match_for_waive(tid)
        if match is None:
            misses.append(tid)
            continue
        level, blocks = match
        for block in blocks:
            key = (block.yaml_stem, block.block_index)
            block_filters.setdefault(key, {}).setdefault(level, set()).add(tid)
    return block_filters, misses


def lookup_paths_into_block_filters(
    yaml_index: YAMLIndex,
    paths: Iterable[str],
) -> tuple[dict[tuple[str, int], dict[str, set[str]]], list[str]]:
    """Resolve YAML-namespace paths via `find_match_for_path`; register each
    covering entry's raw text as identifier so it passes its own `-k` guard.

    Returns (block_filters, unmatched_paths). A path is "unmatched" when
    no YAML entry shares pytest-tree lineage with it. Over-includes
    sibling `-k` variants on purpose: a path change should run every
    parameterization of the affected file/scope.
    """
    block_filters: dict[tuple[str, int], dict[str, set[str]]] = {}
    unmatched: list[str] = []
    for path in paths:
        matches = yaml_index.find_match_for_path(path)
        if matches is None:
            unmatched.append(path)
            continue
        for block, prefix in matches:
            key = (block.yaml_stem, block.block_index)
            ids = block_filters.setdefault(key, {}).setdefault(prefix, set())
            for raw in block.tests:
                if _target_in_filter_subtree(_entry_target(raw), prefix):
                    ids.add(raw)
    return block_filters, unmatched


def resolve_affected_stages(
    block_filters: dict[tuple[str, int], dict[str, set[str]]],
    yaml_index: YAMLIndex,
    stages_by_yaml: dict[str, list[tuple[str, Stage]]],
) -> set[str]:
    """Map block_filters keys → Jenkins stage names via mako condition match."""
    block_by_key = {(b.yaml_stem, b.block_index): b for b in yaml_index.blocks}
    affected: set[str] = set()
    for key in block_filters:
        block = block_by_key.get(key)
        if block is None:
            continue
        for stage_name, stage in stages_by_yaml.get(block.yaml_stem, []):
            if block_matches_stage(block, stage):
                affected.add(stage_name)
    return affected

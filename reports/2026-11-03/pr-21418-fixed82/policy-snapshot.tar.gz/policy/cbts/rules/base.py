# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Rule contracts and shared decision utilities for CBTS."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Optional


def format_reason(reason: object) -> str:
    """Render a structured decision reason as one human line."""
    if not isinstance(reason, dict):
        return str(reason)
    if reason.get("source") == "fallback" and reason.get("reason") == "unhandled_files":
        files = reason.get("files")
        count = len(files) if isinstance(files, list) else "?"
        parts = []
        if coverage_declined := reason.get("coverage_declined"):
            parts.append(f"[tier2] {coverage_declined}")
        parts.append(
            f"[tier1] residual_files={count} "
            f"(not claimed by static rules; not necessarily coverage failures): {files}"
        )
        return " | ".join(parts)
    source = reason.get("source", "?")
    rest = ", ".join(f"{key}={value}" for key, value in reason.items() if key != "source")
    return f"[{source}] {rest}" if rest else f"[{source}]"


@dataclass
class PRInputs:
    """PR data, with executable selection diffs and verified docstring facts.

    ``raw_diffs`` preserves source reconstruction input. ``post_merge``
    reflects /bot run --post-merge.
    """

    changed_files: list[str]
    diffs: dict[str, str]
    post_merge: bool = False
    raw_diffs: dict[str, str] = field(default_factory=dict)
    # Documentation contributions can coexist with executable edits in one file.
    docstring_files: set[str] = field(default_factory=set)
    docstring_only_files: set[str] = field(default_factory=set)


@dataclass
class RuleResult:
    """One rule's contribution.

    `block_filters` is per-block `{filter_prefix: {originating_waive_id, ...}}`
    for Layer 3 narrowing.

    `sanity_relevant` (default True = safe): set False when this rule's
    matched changes have nothing the wheel-sanity check would verify, so
    PackageSanityCheck can be skipped.
    """

    handled_files: set[str]
    affected_stages: set[str]
    scope: Optional[str]
    reason: str
    block_filters: dict[tuple[str, int], dict[str, set[str]]] = field(default_factory=dict)
    sanity_relevant: bool = True
    # True (safe default) iff this rule's matched changes might affect perf
    # benchmarks. Set False when matched changes are pure test infra.
    perfsanity_relevant: bool = True


class Rule(ABC):
    """Base class for CBTS rules.

    `name`: log/reason identifier.
    `needs_diff_for`: file paths/globs whose diffs the rule consumes.
    `handles_docstrings`: receives documentation-only Python file paths;
    other rules receive only files with remaining non-docstring changes.
    `apply(pr)`: return RuleResult or None (not applicable).
    """

    name: str = ""
    needs_diff_for: tuple[str, ...] = ()
    handles_docstrings: bool = False

    @abstractmethod
    def apply(self, pr: PRInputs) -> Optional[RuleResult]: ...

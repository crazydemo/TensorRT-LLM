# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""OpenEngineRule — narrows CI when OpenEngine adapter source changes."""

from __future__ import annotations

from typing import Optional

from cbts.blocks import Stage, YAMLIndex, _entry_target

from ._helpers import resolve_affected_stages, stages_by_yaml_stem
from .base import PRInputs, Rule, RuleResult
from .docs import is_docs_path

_OPENENGINE_SOURCE_PREFIX = "tensorrt_llm/grpc/openengine/"
_OPENENGINE_TEST_PREFIX = "unittest/grpc/openengine/"


def _is_openengine_claim(path: str) -> bool:
    """Return whether an OpenEngine source path needs its focused unit test."""
    return path.startswith(_OPENENGINE_SOURCE_PREFIX) and not is_docs_path(path)


class OpenEngineRule(Rule):
    name = "openengine"
    needs_diff_for: tuple[str, ...] = ()

    def __init__(self, yaml_index: YAMLIndex, stages: dict[str, Stage]) -> None:
        self.yaml_index = yaml_index
        self._stages_by_yaml = stages_by_yaml_stem(stages)

    def apply(self, pr: PRInputs) -> Optional[RuleResult]:
        claimed = {path for path in pr.changed_files if _is_openengine_claim(path)}
        if not claimed:
            return None

        block_filters: dict[tuple[str, int], dict[str, set[str]]] = {}
        for block in self.yaml_index.blocks:
            for entry in block.tests:
                target = _entry_target(entry)
                if not target.startswith(_OPENENGINE_TEST_PREFIX):
                    continue
                key = (block.yaml_stem, block.block_index)
                block_filters.setdefault(key, {}).setdefault(target, set()).add(entry)

        if not block_filters:
            return RuleResult(
                handled_files=claimed,
                affected_stages=set(),
                scope=None,
                reason=(
                    f"openengine: {len(claimed)} claimed file(s); "
                    "no OpenEngine test entry found — fallback"
                ),
            )

        affected = resolve_affected_stages(block_filters, self.yaml_index, self._stages_by_yaml)
        return RuleResult(
            handled_files=claimed,
            affected_stages=affected,
            scope="openengineonly",
            block_filters=block_filters,
            sanity_relevant=False,
            perfsanity_relevant=False,
            reason=(
                f"openengine: {len(claimed)} claimed file(s) → "
                f"{len(block_filters)} test block(s), {len(affected)} stage(s)"
            ),
        )

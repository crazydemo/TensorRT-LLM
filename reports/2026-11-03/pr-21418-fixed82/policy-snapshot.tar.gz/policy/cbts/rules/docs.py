# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""DocsRule — routes documentation changes to docs and CPU validation."""

from __future__ import annotations

from typing import Optional

from cbts.blocks import Stage, YAMLIndex

from ._helpers import block_filters_for_stem, resolve_affected_stages, stages_by_yaml_stem
from .base import PRInputs, Rule, RuleResult
from .out_of_scope import is_out_of_scope

# Stage key declared in jenkins/L0_Test.groovy::docBuildConfigs. This stage is
# not test-db-driven, so CBTS contributes its name literally.
DOCS_STAGE = "CPU-Build_Docs"
CPU_TEST_YAML_STEM = "l0_cpu"

_DOCS_PREFIX = "docs/"
_DOCS_SUFFIXES: tuple[str, ...] = (".md", ".rst")


def is_docs_path(path: str) -> bool:
    """Return whether ``path`` contributes to the repository documentation."""
    return not is_out_of_scope(path) and (
        path.startswith(_DOCS_PREFIX) or path.endswith(_DOCS_SUFFIXES)
    )


class DocsRule(Rule):
    name = "docs"
    needs_diff_for: tuple[str, ...] = ("**/*.py",)
    handles_docstrings = True

    def __init__(self, yaml_index: YAMLIndex, stages: dict[str, Stage]) -> None:
        self.yaml_index = yaml_index
        self._stages_by_yaml = stages_by_yaml_stem(stages)

    def _cpu_block_filters(self) -> dict[tuple[str, int], dict[str, set[str]]]:
        """Keep every entry in every CPU test-db block.

        Tests read files under ``docs/`` directly: model-loader validation
        parses ``docs/source/features/model-express.md``, and telemetry tests
        import ``docs/source/_ext/llmapi_config_telemetry.py``. Until those
        consumers have a complete explicit inventory, changes under ``docs/``
        conservatively run the complete CPU suite. Using each entry's own
        canonical target and raw text preserves `-k` variants through Layer
        3's normal subtree and keyword filtering.

        Literal docstrings contribute this same CPU set, which includes API
        stability and documentation checks, without a consumer-path allowlist.
        """
        return block_filters_for_stem(self.yaml_index, CPU_TEST_YAML_STEM)

    def apply(self, pr: PRInputs) -> Optional[RuleResult]:
        docstring_files = {path for path in pr.docstring_files if not is_out_of_scope(path)}
        claimed = {path for path in pr.changed_files if is_docs_path(path)} | {
            path for path in pr.docstring_only_files if not is_out_of_scope(path)
        }
        if not claimed and not docstring_files:
            return None

        if not docstring_files and not any(path.startswith(_DOCS_PREFIX) for path in claimed):
            return RuleResult(
                handled_files=claimed,
                affected_stages={DOCS_STAGE},
                scope="docsonly",
                sanity_relevant=False,
                perfsanity_relevant=False,
                reason=(
                    f"docs: {len(claimed)} Markdown/reStructuredText file(s) outside "
                    f"{_DOCS_PREFIX} → {DOCS_STAGE}"
                ),
            )

        block_filters = self._cpu_block_filters()
        cpu_stages = resolve_affected_stages(block_filters, self.yaml_index, self._stages_by_yaml)
        if not block_filters or not cpu_stages:
            return RuleResult(
                handled_files=claimed,
                affected_stages=set(),
                scope=None,
                reason=(
                    f"docs: {len(claimed | docstring_files)} documentation/docstring file(s); "
                    "no CPU test-db blocks or stages resolved — fallback"
                ),
            )

        affected_stages = cpu_stages | {DOCS_STAGE}
        return RuleResult(
            handled_files=claimed,
            affected_stages=affected_stages,
            scope="docsonly",
            block_filters=block_filters,
            sanity_relevant=False,
            perfsanity_relevant=False,
            reason=(
                f"docs: {len(claimed | docstring_files)} documentation/docstring file(s) → "
                f"{DOCS_STAGE} + "
                f"{len(cpu_stages)} CPU test stage(s)"
            ),
        )

<!-- SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved. -->
<!-- SPDX-License-Identifier: Apache-2.0 -->

# rules/

One rule per file; each inherits from `Rule` in `base.py`. Shared lookup
helpers live in `_helpers.py`. See the top-level [README](../../README.md)
for the overall CBTS architecture.

## Current rules

| File | Class | Scope | Triggers on |
|---|---|---|---|
| `waives.py` | `WaivesRule` | `waiveonly` | `tests/integration/test_lists/waives.txt` |
| `tests_def.py` | `TestsDefRule` | `testdefonly` | `tests/**/*` (any file under tests/) |
| `test_list.py` | `TestListRule` | `testlistonly` | `tests/integration/test_lists/test-db/*.yml` |
| `visual_gen.py` | `VisualGenRule` | `visualgenonly` | `examples/visual_gen/**`, `scripts/visualgen_eval/**`, `tensorrt_llm/_torch/visual_gen/**`, `tensorrt_llm/media/**`, `tensorrt_llm/visual_gen/**` (each excl. docs) |
| `spec_dec.py` | `SpecDecRule` | `specdeconly` | `tensorrt_llm/_torch/speculative/**`, `tensorrt_llm/models/{eagle,medusa,redrafter}/**`, `examples/{eagle,medusa,redrafter,draft_target_model,ngram}/**`, `examples/llm-api/llm_speculative_decoding.py` (each excl. docs) |
| `modeling_v2.py` | `ModelingV2Rule` | `modelingv2only` | `tensorrt_llm/_torch/_experimental/modeling_v2/**`, `cpp/tensorrt_llm/modeling_v2/**`, `cpp/cmake/modules/modeling_v2.cmake` (excl. docs); per model node for changes under `models/` |
| `agent_flow.py` | `AgentFlowRule` | `agentflowonly` | `agent-flow/**` (excl. docs and out-of-scope metadata) → the single `CPU-AgentFlow-UnitTest` stage; not test-db-driven |
| `openengine.py` | `OpenEngineRule` | `openengineonly` | `tensorrt_llm/grpc/openengine/**` (excl. docs) → the `l0_cpu` block containing `unittest/grpc/openengine/` |
| `docs.py` | `DocsRule` | `docsonly` | Outside noop paths: `docs/**` and verified Python docstring edits → `CPU-Build_Docs` plus complete `l0_cpu`; other `**/*.md` / `**/*.rst` → `CPU-Build_Docs` only |
| `out_of_scope.py` | `OutOfScopeRule` | `noop` | Reviewed metadata paths, root issue-template and developer-assistant folders, `.gitignore` at any depth, conventional clang filenames under `cpp/`, verified static-check-only `pyproject.toml` edits, QA/dev lists, timing caches, microbenchmarks, and CBTS infrastructure |

## DocsRule

Claims every file under `docs/` plus Markdown and reStructuredText files
anywhere in the repository, excluding paths recognized by `is_out_of_scope`.
The same exclusion applies to Python docstring contributions. Every claim contributes the literal
`CPU-Build_Docs` stage, which runs Doxygen and Sphinx `make html`. Changes under
`docs/` additionally keep every block and entry in `l0_cpu.yml`, because CPU
tests directly read documentation sources such as `model-express.md` and import
the telemetry extension under `docs/source/_ext/`. If the CPU test-db blocks or
stages cannot be resolved for a `docs/` change, the rule forces fallback instead
of silently running docs alone. Markdown and reStructuredText outside `docs/`
run only the docs build, matching the legacy Docs path without adding unrelated
CPU tests.

On a docs-only PR, `L0_MergeRequest.groovy` skips the SBSA build track, so the
resolved `CPU-Generic-arm-*` stage is recorded in `affected_stages` but is not
launched; the x86 CPU stage supplies the CPU validation. Mixed PRs continue to
follow the normal architecture gates. Documentation files inside another rule's
source prefix remain excluded from that source rule, and mixed documentation
and targeted-test changes combine by unioning their stages.

The rule also consumes verified docstring edits in existing Python modules,
classes, and functions. The input analyzer checks the unmodified patch against
the post-image, parses both images, and separates literal docstring lines from
code lines. A Python file with only those edits is claimed by `DocsRule` and
excluded from the other rules. For a mixed file, the rule contributes the docs
build and complete CPU validation without claiming the file; other rules and
coverage analyze the remaining executable edits. The original patch remains
available to coverage to reconstruct the pre-image. Selections combine by
union, including the independent docs stage when coverage narrows the residual.

Missing or mismatched patches, unparsable source, ambiguous scope identities,
new definitions, and docstrings sharing a line with executable statements keep
their normal code impact. Assigned strings, f-strings, non-leading string
expressions, and explicit `__doc__` assignments are executable changes. This
policy treats recognized literal docstring edits as low-risk documentation;
it does not infer a complete graph of runtime docstring consumers.


## WaivesRule

Reads `+`/`-` lines from the diff, normalizes each to a test id, then for
each id calls `YAMLIndex.find_match_for_waive` to walk the pytest parent
chain (function → class → file → dir) until a YAML entry matches. The
matched level becomes that block's Layer 3 filter prefix; stages whose
`mako` matches the block's `condition` go into `affected_stages`.

Outcomes:

- No actionable diff (whitespace / comment-only) → `scope=noop`.
- All ids unmatchable → `scope=noop`. The waived test isn't in any
  pre-merge YAML, so adding/removing its SKIP doesn't affect what runs.
- Some ids matched → `scope=waiveonly`; unmatchable misses are noted in
  the reason and ignored for narrowing.
- `sanity_relevant=True` when any matched block belongs to
  `l0_sanity_check`.

## TestsDefRule

For each file under `tests/` in the diff:

1. `git_path_to_yaml_key` translates the repo path to a YAML namespace
   key, or returns `None` for paths outside YAML's view (top-level
   integration `conftest.py`, dirs no YAML entry references such as
   `tests/integration/test_input_files/`).
2. `_compute_anchors` parses the diff's post-image line numbers and maps
   them through the file's AST to produce one of:
   - function-level anchors `path::Class::method` (every changed line
     lands in a `test_*` function inside a `Test*` class), or
   - file-level anchor `path` (any line lands at module scope, AST parse
     fails, or the file is unreadable — the latter covers .yaml/.txt/
     .json/etc. data files).
   Decorator lines count as part of what they decorate: `_scope_start_line`
   extends each node's range up over its `decorator_list`, so editing
   `@pytest.mark.parametrize` stays at method level and a class-level
   `@skip_pre_blackwell` stays at class level instead of dropping to
   module scope.
   Python helper modules instead query the shared `RepositoryReferenceIndex`.
   A complete set of direct `test_*.py` importers becomes the anchors; an
   ambiguous, dynamic, transitive, or non-test importer retains the directory
   fallback.
3. `lookup_paths_into_block_filters` calls `find_match_for_path`
   (bidirectional pytest-tree lineage) for each anchor; matches feed
   `block_filters`. For non-`test_*.py` paths, the lookup walks up
   enclosing directories to the narrowest YAML-covered ancestor — so
   `disaggregated/test_configs/foo.yaml` lifts to `disaggregated/`,
   `unittest/api_stability/references/llmapi.yaml` lifts to
   `unittest/api_stability/`.

### Deletion-only diffs

Deleted lines have no post-image position. `iter_diff_post_line_numbers`
anchors them to the next surviving line, which can land outside the scope
they were deleted from — between two classes for a `.py` file, or on the
next model section for a reference YAML. Rather than widening to
file/dir level, both paths re-read the deleted side from the diff's own
pre-image view (`iter_diff_pre_image`: context + `-` lines, in-hunk
order), where a deleted class's `class` statement or a deleted section's
key line is directly visible:

- `.py`: `_recover_deleted_scope_anchors` runs only after post-image
  mapping already failed, so modification diffs keep their finer
  method-level anchors. `_py_class_scopes_from_deletions` attributes at
  class level — a method-level walk would have to guess which `def` a
  stray decorator line belongs to.
- reference YAML: `_yaml_top_keys_from_deletions` reads `-` lines,
  `iter_diff_added_post_line_numbers` reads `+` lines off the post-image.

Both return `None` — forcing the file-level fallback — when a `-` line's
owning scope is not visible inside its hunk, since only 3 context lines
are guaranteed. Pre-image *line numbers* are never used:
`strip_noop_diff_lines` drops blank / comment-only `-` lines, which
shifts every later pre-image number.

### accuracy/references/*.yaml

Top-level keys name what a section is a reference for, and resolve to
anchors under `accuracy/test_*.py` so the lineage walk matches every
parametrization:

- HF model name (15 of the 16 files) → test classes carrying that
  `MODEL_NAME = "<hf>"` literal. A diff under
  `meta-llama/Llama-3.1-8B-Instruct:` narrows to
  `accuracy/test_*.py::TestLlama3_1_8BInstruct` rather than the whole
  `accuracy/` subtree.
- `TestC::test_m` id (`acceptance_length.yaml` only) → that method in
  every module defining `TestC`.

Resolving to *no* anchor is a zero-impact claim, not a failure, when the
changed keys are also absent from the post-PR YAML: that is the shape of
a test-pruning PR, which drops a reference section and its test in one
commit, so nothing left in the tree can read it. Keys that survive in
the YAML but resolve to no test keep the dir-level fallback — some test
this rule failed to resolve may still read them.

Outcomes:

- Path is out-of-namespace (`git_path_to_yaml_key` returns `None`):
  - basename is `test_*.py`: claimed as noop — pytest doesn't auto-import
    test files into other tests, so an L0-unreferenced standalone test
    file has no impact on what L0 runs.
  - basename is conftest / `__init__` / a helper / data file: unhandled
    — Selector reports it and falls back. Could be implicitly imported
    (top-level conftest, sys-path helpers, test input fixtures).
- Path is in-namespace but its anchors match no YAML entry — no
  YAML-covered ancestor at any walk-up level, or a zero-impact claim
  from the accuracy-reference path: claimed as no-narrow contribution
  (`scope=noop` if all paths are like this; a miss-note in the reason
  on partial-narrow runs).
- Block-filter coverage ≥ `BLAST_RADIUS_FRACTION` (0.8) of total YAML
  blocks: `scope=None` (rule cannot usefully narrow — fallback).
- `sanity_relevant` / `perfsanity_relevant` follow from the matched
  blocks' YAML stem.

## TestListRule

Per touched `test-db/*.yml`, classifies each `+`/`-` line:

- Comment / blank → ignored.
- Indented `- <pytest_id>` (entry within a block) → recorded as added or
  removed.
- Anything else (top-level `- condition:`, mako edits, structural shifts)
  → `structural` list.

Only **added** entries drive narrowing; removals don't need verification
(the test either still runs elsewhere or is fully retired).

Outcomes:

- Any structural change → `scope=None` (Layer 2 stage matching depends
  on `condition`/mako; fallback).
- No additions (only removals or comment-only edits) → `scope=noop`.
- All added entries unresolvable against the post-PR YAML → `scope=noop`
  (the entries don't appear in any block).
- Some added entries resolved → `scope=testlistonly`; unresolved entries
  are noted in the reason and ignored for narrowing.

## VisualGenRule

Path-only rule. Claims source files under `examples/visual_gen/`,
`scripts/visualgen_eval/`, `tensorrt_llm/_torch/visual_gen/`,
`tensorrt_llm/media/`, and `tensorrt_llm/visual_gen/` (excluding `.md`,
which `OutOfScopeRule` claims as noop). fused-DiT paths stay unclaimed:
those diffs also touch `inplace_info()` in
`tensorrt_llm/_torch/compilation/utils.py`, which no VG rule claims.
Image suffixes are intentionally NOT excluded: VG ships reference images
used as test fixtures (e.g. `examples/visual_gen/cat_piano.png` and
`examples/visual_gen/serve/media/woman_skyline_original_720p.jpeg` are
loaded by `tests/unittest/_torch/visual_gen/`), so edits to them must
still force VG stages.

Block selection — entry-pattern based only:
VisualGen has no `condition.terms.backend` of its own; VG entries
live in `backend: pytorch` and `backend: tensorrt` blocks. A block
"belongs to VG" iff any of its `tests:` entries lives under a dedicated
`visual_gen/` test path or is the VisualGen perf-sanity entry under
`perf/`.

For each matched block, `block_filters` keeps only the VG entries.
Non-VG siblings in the same block stay governed by other rules.

Outward-facing fallback: VisualGen public symbols and
`tensorrt_llm.media.*` are imported eagerly by non-VG startup paths such
as `commands/serve.py`, `commands/utils.py`, and
`serve/openai_server.py`. Both package prefixes
(`tensorrt_llm/visual_gen/`, `tensorrt_llm/media/`) are listed in
`_VG_OUTWARD_PREFIXES`; touching any non-doc file under them claims the
changed files but emits `scope=None` so Selector falls back to baseline.
This protects trtllm-serve / trtllm-bench startup paths from VG
signature drift slipping through pre-merge.

Outcomes:

- No VG source files in the diff → rule returns `None`.
- VG source touched, all internal (`examples/visual_gen/**`,
  `scripts/visualgen_eval/**`, or `tensorrt_llm/_torch/visual_gen/**`)
  → `scope=visualgenonly`;
  sanity off (VG changes don't affect wheel sanity); perfsanity on iff
  a matched block lives in `l0_perf` or `*perf_sanity*`.
- VG source touched, any outward-facing path under
  `tensorrt_llm/visual_gen/` or `tensorrt_llm/media/` → `scope=None`
  (fallback).
- VG source touched but no VG block found anywhere (defensive) →
  `scope=None` (fallback).

## SpecDecRule

Path-only rule. Claims source files under `tensorrt_llm/_torch/speculative/`,
`tensorrt_llm/models/{eagle,medusa,redrafter}/`,
`examples/{eagle,medusa,redrafter,draft_target_model,ngram}/`, and the
single file `examples/llm-api/llm_speculative_decoding.py` (excluding
documentation paths, which `DocsRule` routes to `CPU-Build_Docs`). Other suffixes —
including images — are NOT excluded: a binary asset under a spec-dec
path could be a test fixture, so the rule keeps claiming them and
forces spec-dec stages to re-run.

Block selection — entry-pattern based only:
Spec-dec has no `condition.terms.backend` of its own; entries live in
`backend: pytorch` and `backend: tensorrt` blocks. A block "belongs to
spec-dec" iff any of its `tests:` entries matches one of the stable
markers in `_SPEC_ENTRY_PATTERNS`:

- Filename / method-name markers: `test_eagle`, `test_medusa`,
  `test_redrafter`, `test_ngram`, `test_draft_target_model`,
  `test_ad_speculative_decoding`, `unittest/_torch/speculative/`,
  `test_spec_decoding_metrics`, `test_llmapi_speculative_decoding`,
  `speculative_decoding_bls`, `test_mtp`.
- MTP parametrize-id markers: `mtp_nextn` (filtered — see below),
  `_mtp` (covers `throughput_mtp`, `*_mtp1`, `*_mtp3` suffixes).

For each matched block, `block_filters` keeps only the spec-dec entries.
Non-spec-dec siblings in the same block stay governed by other rules.

`mtp_nextn=0` carve-out: those parametrizations test MTP-disabled
baseline behavior, not the spec-dec code path. `_entry_is_spec` drops
the bare `mtp_nextn` signal when the entry also contains
`mtp_nextn=0`; another spec-dec marker must match for the entry to
qualify. As of May 2026 all 183 active `mtp_nextn=0` entries lack any
other marker and are therefore dropped.

No outward fallback needed: the only non-spec-dec eager import of
spec-dec types is `tensorrt_llm/commands/build.py` pulling
`SpeculativeDecodingMode` from `tensorrt_llm/models/modeling_utils.py`,
which lives outside `_SPEC_SRC_PREFIXES` and therefore is never claimed
by this rule. PRs that touch `modeling_utils.py` naturally fall back to
baseline.

Outcomes:

- No spec-dec source files in the diff → rule returns `None`.
- Spec-dec source touched → `scope=specdeconly`; sanity off (spec-dec
  changes don't affect wheel sanity); perf-sanity follows the matched
  blocks (True iff any matched block lives in `*_perf_sanity*` yaml).
- Spec-dec source touched but no spec-dec block found anywhere
  (defensive) → `scope=None` (fallback).

## ModelingV2Rule

Path-only rule. Claims non-documentation source changes under
`tensorrt_llm/_torch/_experimental/modeling_v2/`, the self-contained second modeling
path (one flat forward per checkpoint/arch/parallel triple, assembled
from a catalog of op wrappers), including each family's native code
(`models/<family>/csrc/`, `models/<family>/<target>/csrc/`: one torch-op library
per model family, loaded only when routing picks one of the family's targets),
plus what every family library shares: `cpp/tensorrt_llm/modeling_v2/` and the
native build module `cpp/cmake/modules/modeling_v2.cmake`.

Scope — per model node, else all of modeling_v2: source changes under
`models/` (native `csrc/` included) select the nearest model node's unit tests
and the accuracy gates of its targets. Family-shared code selects the whole
family. A covering directory entry is retained when no more specific entry
exists, unless it ignores that node. Whole-tree unit checks are always retained.
Shared Python or native infrastructure selects every modeling_v2 entry, as does
an unreadable routing tree. If no modeling_v2 entry matches, the rule falls back
to baseline.

`.md` exclusion carries more weight here than elsewhere: every catalog
entry ships a contract document, so roughly a fifth of the subtree is
Markdown. Claiming those would let a documentation-only PR pull in
multi-GPU GB300 stages. Other suffixes are NOT excluded — a data file
under the subtree could be a fixture, so the rule keeps claiming it
(safe over-run).

Block selection — entry-pattern based only:
modeling_v2 has no `condition.terms.backend` of its own; its entries sit
in `backend: pytorch` blocks beside everything else. A block belongs to
modeling_v2 iff one of its `tests:` entries matches
`_MV2_ENTRY_PATTERNS`:

- `unittest/_torch/modeling_v2/` — the unit tests: one directory entry
  (`--ignore` of `comm/`) that collects the catalog matrix and every
  family's tests under `models/<family>`, plus `comm/` on
  `l0_gb300_multi_gpus` for the 4-rank collectives.
- `test_modeling_v2_` — the accuracy gates, and any future unit file.

Both markers are exact by construction rather than by luck: every test
file in the subtree is named `test_modeling_v2_*` precisely so it cannot
collide with the upstream test of the same op. So unlike `SpecDecRule`'s
`mtp_nextn`, no substring here can claim an unrelated entry and no
carve-out is needed.

Outward fallback: not needed, and by design rather than by accident.
Nothing beyond the resolver module is imported unless `LLM(modeling_v2=...)`
is on — the model loader calls `modeling_v2_resolve_on_all_ranks`, which
returns immediately when the switch is off, and the routing modules are
imported lazily behind it. The callers outside the subtree,
`tensorrt_llm/_torch/pyexecutor/model_loader.py` (decides) and
`tensorrt_llm/_torch/models/modeling_auto.py` (reads the decision off
`ModelConfig`), are deliberately left unclaimed: a change to the shared
resolver falls back to baseline, which is what it deserves.

`sanity_relevant=False` — the subtree ships no user-facing entry point
and is not imported by `trtllm-serve` or by `import tensorrt_llm`, so
none of it is what PackageSanityCheck verifies about the wheel.
`perfsanity_relevant` is dynamic (True only if a matched block lives in
a `*_perf_sanity*` yaml); there are no modeling_v2 perf-sanity entries
today, so it aggregates to False.

Source changed but no modeling_v2 block in any yaml (defensive) →
`scope=None` (fallback).

## OpenEngineRule

Claims non-documentation source changes under `tensorrt_llm/grpc/openengine/` and keeps only test-db
entries under `unittest/grpc/openengine/`. The stub-based tests are registered in `l0_cpu.yml`, so
they resolve to `CPU-Generic-x86-1` / `CPU-Generic-arm-1` — one split each, and stages CBTS runs
unconditionally (`ALWAYS_RUN_STAGE_PREFIX`), so they still run on every baseline and fallback
pipeline. `test_capability_conformance.py` builds a real `LLM` and so is registered in `l0_a10.yml`,
adding `A10-PyTorch-*`: an OpenEngine change does pull one GPU shard. Any GPU serves — the model is
TinyLlama-1.1B — so it sits with the other gateway tests rather than claiming a scarcer type.
OpenEngine's private bindings and gRPC runtime are base package dependencies, so no stage-name guard
decides which gateway a shard can import. If no OpenEngine test entry is registered, the rule
returns `scope=None` and falls back to the baseline rather than silently skipping coverage.

Tests under `tests/unittest/grpc/openengine/` remain owned by `TestsDefRule`;
source-plus-test changes combine through the `testsonly` scope family.

## OutOfScopeRule

Claims changes outside product-test selection as `scope=noop`, contributing no
test stages or block filters. The main entry point still retains the always-run
CPU stages. With only noop contributions, the source `l0_cpu` list runs without
case filtering. In a mixed PR, other rules or coverage select the remaining
changes; noop adds no requirement to retain the entire CPU suite. Build and
repository checks remain upstream.

`OUT_OF_SCOPE_EXACT_PATHS` lists reviewed metadata files by complete repository
path. A new YAML, JSON, TOML, or template file is not automatically exempt,
including at the repository root or under `scripts/` and `jenkins/`.

| Paths | Purpose |
|---|---|
| `.github/CODEOWNERS` | Repository ownership metadata |
| `LICENSE` | License metadata packaged by the upstream build |
| `.pre-commit-config.yaml`, `agent-flow/.pre-commit-config.yaml` | Pre-commit checks |
| `.clang-format`, `.clang-tidy`, `.clangd`, `.cmake-format.json`, `.editorconfig`, `.cursorignore` | Formatting and editor settings |
| `.coderabbit.yaml`, `.nspect-allowlist.toml` | Review and security checks |
| `scripts/bandit.yaml`, `jenkins/license_cpp.json` | External checks |
| `legacy-files.txt`, `ruff-legacy.toml`, `ruff-legacy-baseline.json` | Legacy lint configuration |
| `scripts/templates/precommit-legacy-files.j2`, `scripts/templates/pyproject-format-exclude.j2`, `scripts/templates/ruff-legacy.toml.j2` | Lint configuration templates |

`OUT_OF_SCOPE_PREFIXES` covers the complete root directories
`.github/ISSUE_TEMPLATE/`, `.codex/`, and `.claude/`, including new files and all
file types. The trailing slash preserves the directory boundary: sibling paths
such as `.github/workflows/` and `.claude-extra/`, and nested paths such as
`nested/.codex/`, are not exempt. Markdown, reStructuredText, and Python
docstrings inside exempt subtrees do not contribute a docs stage. The input
loader leaves those Python files available for `OutOfScopeRule` to claim.

`OUT_OF_SCOPE_FILENAMES` recognizes the exact basename `.gitignore` at every
repository depth, including future directories. Git uses that complete name;
`fixture.gitignore`, `.gitignore.bak`, and `.gitignore-template` are not exempt.

`OUT_OF_SCOPE_DIRECTORY_FILENAMES` additionally recognizes the complete
basenames `.clang-format`, `.clang-tidy`, and `.clangd` under `cpp/`.
Directory patterns match the complete parent path; `cpp/**` includes its
descendants. A file such as `cpp/kernels/runtime.clangd` is not exempt. There
are no general file-extension exemptions in this rule.

Product configuration, fixtures, workflows, dependency lists, and unrecognized
metadata continue through the other rules or fallback. Root `.txt` files are
not generally exempt.

A repository-wide tracked-file scan on 2026-10-15 examined 16,405 paths.
`.gitignore` does not filter tracked source out of checkout or the explicit
wheel staging process. `.gitattributes` remains
outside this rule because it controls LFS, text conversion, and export behavior;
`.dockerignore` controls the actual Docker build context and also stays outside.
`.devcontainer/` has no subtree exemption: `devcontainer.json`
invokes `make_env.py`, which can run `make -C docker devel_build`, and Compose
settings change the local container environment. Current Jenkins pipelines do
not directly consume these files, but local build inputs still require normal
analysis or fallback. CI workflows, image tags, runtime example inputs,
test fixtures, pytest settings, requirements, and build files retain their other
rules or fallback. Outside exempt subtrees, Markdown and reStructuredText remain
owned by `DocsRule`.

Outside exempt subtrees, `pyproject.toml` mixes static checks with packaging and
dependencies. The rule
claims it only when a verified raw patch reconstructs the pre-image and every
non-comment line outside `tool.ruff`, `tool.isort`, `tool.yapf`, `tool.codespell`,
`tool.autoflake`, and `tool.mypy` tables remains unchanged. This applies at any
depth. Missing patches, unreadable/new/deleted files, multiline strings, quoted
headers, and ambiguous section syntax remain unclaimed. The conservative section
walker does not require a new TOML dependency on Python 3.10.

The existing subtree exemptions also remain:

- `tests/integration/test_lists/qa/` — QA-only test lists, separate
  nightly workflows.
- `tests/integration/test_lists/dev/` — developer-side artifacts, no L0
  consumer.
- `tests/integration/defs/.test_durations` — pytest-split timing cache.
- `tests/integration/defs/agg_unit_mem_df.csv` — worker parallelism metadata.
- `tests/microbenchmarks/` — benchmarking scripts, no L0 stage.
- `jenkins/scripts/cbts/` — selection infrastructure.

Image extensions (`.png`, `.jpg`, `.jpeg`, `.gif`, `.svg`, `.webp`) are
intentionally NOT claimed: image files anywhere in the repo can be test
fixtures (e.g. `examples/visual_gen/cat_piano.png` is loaded by
`tests/unittest/_torch/visual_gen/`), and location alone cannot
distinguish a fixture from a doc diagram. Image edits therefore fall
back to baseline unless a more specific rule (AD / VG / spec-dec)
claims them inside its source subtree.

`OUT_OF_SCOPE_EXACT_PATHS`, `OUT_OF_SCOPE_FILENAMES`, `OUT_OF_SCOPE_PREFIXES`,
and `OUT_OF_SCOPE_DIRECTORY_FILENAMES` in `out_of_scope.py` list the policies.

## Helpers (`_helpers.py`)

| Helper | Used by | Purpose |
|---|---|---|
| `iter_diff_changes(diff)` | waives, testlist | Yields `(sign, body)` for each `+`/`-` content line. |
| `iter_diff_post_line_numbers(diff)` | testdef | Yields post-image line numbers for AST scope mapping; `-` lines anchor to the next surviving line. |
| `iter_diff_added_post_line_numbers(diff)` | testdef | Same, but `+` lines only — for callers reading meaning off the post-image. |
| `iter_diff_pre_image(diff)` | testdef | Yields `(sign, body)` reconstructing each hunk's pre-image (`-` + context); `("@", "")` marks a hunk boundary. |
| `lookup_ids_into_block_filters` | waives, testlist | Runs `find_match_for_waive` over a set of test ids; returns block_filters and miss set. |
| `lookup_paths_into_block_filters` | testdef | Runs `find_match_for_path` over a set of anchors; returns block_filters and miss set. |
| `resolve_affected_stages` | all narrowing rules | Maps `block_filters` keys to stage names via `stages_by_yaml_stem`. |
| `stages_by_yaml_stem` | all rules | Builds `{yaml_stem: [Stage, ...]}` index from the parsed Groovy stages. |

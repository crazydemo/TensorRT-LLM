#!/usr/bin/env python3
# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""CBTS entry point.

Modes:
  python3 -m cbts.command main --list-needed-diffs
      Print the union of rules' `needs_diff_for` patterns, one per line.
  python3 -m cbts.command main INPUT_JSON
      INPUT_JSON: {changed_files: [...], diffs: {path: diff}, post_merge: bool}.
      Stages are parsed from jenkins/L0_Test.groovy; YAMLs from
      tests/integration/test_lists/test-db/. Decision JSON goes to stdout
      with keys: scope, affected_stages, reasons, test_db_dir_override,
      affected_stage_test_counts, affected_stage_split_counts.

Run from the TRT-LLM repo root or pass --repo-root.
"""

from __future__ import annotations

import json
import sys
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Optional

import click

from cbts.blocks import (
    ALWAYS_RUN_STAGE_PREFIX,
    Stage,
    YAMLIndex,
    compute_stage_split_counts,
    compute_stage_test_counts,
    load_durations,
    parse_stages_from_groovy,
    write_filtered_test_db,
)
from cbts.coverage.tier import (
    DEFAULT_NO_DATA_POLICY,
    NO_DATA_POLICIES,
    apply_coverage_tier,
    compute_coverage_stage_counts,
    coverage_preflight,
    open_db,
    write_coverage_test_db,
)
from cbts.python_docstring_analysis import split_docstring_diff
from cbts.rules._helpers import iter_diff_changes, strip_noop_diff_lines
from cbts.rules.agent_flow import AgentFlowRule
from cbts.rules.base import PRInputs, Rule, RuleResult, format_reason
from cbts.rules.docs import DocsRule
from cbts.rules.modeling_v2 import ModelingV2Rule
from cbts.rules.openengine import OpenEngineRule
from cbts.rules.out_of_scope import OutOfScopeRule, is_out_of_scope
from cbts.rules.spec_dec import SpecDecRule
from cbts.rules.test_list import TestListRule
from cbts.rules.tests_def import TestsDefRule
from cbts.rules.visual_gen import VisualGenRule
from cbts.rules.waives import WaivesRule

# Files the coverage tier maps to qualnames; without their diffs it stays file-level.
COVERAGE_NEEDS_DIFF_FOR: tuple[str, ...] = ("**/*.py",)

# --- Rule registry -----------------------------------------------------------

# Classes are used for `--list-needed-diffs` (no need to construct).
RULE_CLASSES: list[type[Rule]] = [
    WaivesRule,
    TestsDefRule,
    TestListRule,
    VisualGenRule,
    SpecDecRule,
    ModelingV2Rule,
    AgentFlowRule,
    OpenEngineRule,
    DocsRule,
    OutOfScopeRule,
]


def build_rules(
    yaml_index: YAMLIndex,
    stages: dict[str, Stage],
    repo_root: Path,
) -> list[Rule]:
    return [
        WaivesRule(yaml_index, stages),
        TestsDefRule(yaml_index, stages, repo_root=repo_root),
        TestListRule(yaml_index, stages, repo_root=repo_root),
        VisualGenRule(yaml_index, stages),
        SpecDecRule(yaml_index, stages),
        ModelingV2Rule(yaml_index, stages, repo_root=repo_root),
        AgentFlowRule(yaml_index, stages),
        OpenEngineRule(yaml_index, stages),
        DocsRule(yaml_index, stages),
        OutOfScopeRule(yaml_index, stages, repo_root=repo_root),
    ]


# --- Selector ---------------------------------------------------------------


@dataclass
class SelectionResult:
    """Aggregated CBTS decision serialized to JSON for Groovy."""

    scope: Optional[str]
    # Per-rule scopes of every fired rule incl noop (the combined `scope`
    # rolls these up; noop gives way to actionable scopes there).
    scopes: list[str] = field(default_factory=list)
    affected_stages: set[str] = field(default_factory=set)
    reasons: list[dict] = field(default_factory=list)
    block_filters: dict[tuple[str, int], dict[str, set[str]]] = field(default_factory=dict)
    test_db_dir_override: Optional[str] = None
    # Per-stage kept-entry count (decision telemetry / diagnostics).
    affected_stage_test_counts: dict[str, int] = field(default_factory=dict)
    # Per-stage duration-sized pytest-split count (Groovy cbtsResizeSplits slices to it).
    affected_stage_split_counts: dict[str, int] = field(default_factory=dict)
    # Aggregated `any(rule.sanity_relevant)` across fired rules. Default
    # True is safe; Groovy Layer 2 keeps PackageSanityCheck only when True.
    sanity_required: bool = True
    # Aggregated `any(rule.perfsanity_relevant)`. Groovy Layer 2 keeps
    # *-PerfSanity-* stages only when True.
    perfsanity_required: bool = True
    # set by coverage tier; Groovy re-adds multiGpuJobs under MULTI_GPU_FILE_CHANGED gate
    enable_multi_gpu: bool = False
    coverage_dropped_stages: list[str] = field(default_factory=list)
    # Post-merge build the consulted touch DB came from; makes a decision replayable.
    coverage_db_build: Optional[int] = None
    # Revision the DB was collected at and main's distance from it.
    coverage_db_commit: Optional[str] = None
    coverage_db_lag: Optional[int] = None
    # The PR's base and the DB's distance from it, retained for telemetry.
    coverage_db_base_commit: Optional[str] = None
    coverage_db_drift: Optional[int] = None
    coverage_db_drift_status: str = ""
    # Whether drift was measurable: ok / unknown; empty when no DB was consulted.
    coverage_freshness: str = ""
    # Files left after Tier 1; the patch compatibility check is scoped to these paths.
    coverage_residual_files: list[str] = field(default_factory=list)
    # clean / conflict / unknown / not_attempted.
    coverage_compatibility: str = "not_attempted"
    # Stable classification for coverage-tier fallback telemetry.
    coverage_decline_reason: str = ""
    coverage_decline_category: str = ""
    # Residual files the forge API returned no patch for; they fall back to file level.
    coverage_no_diff_files: int = 0

    def to_json(self) -> str:
        data = {
            "scope": self.scope,
            "scopes": list(self.scopes),
            "affected_stages": sorted(self.affected_stages),
            "reasons": list(self.reasons),
            "test_db_dir_override": self.test_db_dir_override,
            "affected_stage_test_counts": dict(self.affected_stage_test_counts),
            "affected_stage_split_counts": dict(self.affected_stage_split_counts),
            "sanity_required": self.sanity_required,
            "perfsanity_required": self.perfsanity_required,
            "enable_multi_gpu": self.enable_multi_gpu,
            "coverage_dropped_stages": sorted(self.coverage_dropped_stages),
            "coverage_db_build": self.coverage_db_build,
            "coverage_db_commit": self.coverage_db_commit,
            "coverage_db_lag": self.coverage_db_lag,
            "coverage_db_base_commit": self.coverage_db_base_commit,
            "coverage_db_drift": self.coverage_db_drift,
            "coverage_db_drift_status": self.coverage_db_drift_status,
            "coverage_freshness": self.coverage_freshness,
            "coverage_residual_files": list(self.coverage_residual_files),
            "coverage_compatibility": self.coverage_compatibility,
            "coverage_decline_reason": self.coverage_decline_reason,
            "coverage_decline_category": self.coverage_decline_category,
            "coverage_no_diff_files": self.coverage_no_diff_files,
        }
        return json.dumps(data, indent=2, ensure_ascii=False) + "\n"


def _load_coverage_db_meta(path: Optional[str]) -> dict:
    """artifact.py's selection JSON; empty when absent or unreadable."""
    if not path:
        return {}
    try:
        data = json.loads(Path(path).read_text())
    except (OSError, json.JSONDecodeError) as e:
        print(f"coverage DB meta unreadable ({path}): {e}", file=sys.stderr)
        return {}
    return data if isinstance(data, dict) else {}


def _coverage_decline_category(reason: str) -> str:
    """Map a human-readable Tier-2 decline reason to a stable telemetry category."""
    categories = (
        ("a rule forced fallback", "rule_forced_fallback"),
        ("no residual", "no_residual"),
        ("non-core-Python residual file", "non_core_python"),
        ("non-Python residual file", "non_python"),
        ("shared test infrastructure change", "shared_test_infrastructure"),
        ("zero-touch residual file", "zero_touch"),
        ("no usable diff", "no_usable_diff"),
        ("import-executed change", "import_executed"),
        ("unparsable source", "unparsable_source"),
        ("closure change", "closure_change"),
        ("coverage tier errored", "tier_error"),
    )
    return (
        next((category for text, category in categories if text in reason), "other")
        if reason
        else ""
    )


def _rule_reason(rule, r) -> dict:
    """One rule's structured reason entry: `{source, blocks, stages}`."""
    return {
        "source": rule.name,
        "blocks": len(r.block_filters),
        "stages": len(r.affected_stages),
    }


# Scopes that compose: a PR mixing waive + test-def + test-list edits
# combines to a single "testsonly" scope rather than falling back.
_TESTSONLY_FAMILY: frozenset[str] = frozenset(
    {
        "waiveonly",
        "testdefonly",
        "testlistonly",
        "visualgenonly",
        "specdeconly",
        "modelingv2only",
        "agentflowonly",
        "openengineonly",
        "docsonly",
    }
)


def _combine_scopes(scopes: list[str]) -> Optional[str]:
    """Combine rule scopes.

    Rules with scope="noop" (out-of-scope claims) give way to any
    actionable rule that also fired. When only noop fired, returns
    "noop". Otherwise: identical scopes pass through; testsonly-family
    mixes combine to "testsonly"; anything else returns None.
    """
    if not scopes:
        return None
    real = [s for s in scopes if s != "noop"]
    if not real:
        return "noop"
    s = set(real)
    if len(s) == 1:
        return next(iter(s))
    if s <= _TESTSONLY_FAMILY:
        return "testsonly"
    return None


class Selector:
    def __init__(self, stages: dict[str, Stage]) -> None:
        self.stages = stages

    def run(self, pr: PRInputs, rules: list[Rule]) -> SelectionResult:
        code_pr = replace(
            pr,
            changed_files=[
                path for path in pr.changed_files if path not in pr.docstring_only_files
            ],
        )
        pairs: list[tuple[Rule, RuleResult]] = []
        for rule in rules:
            result = rule.apply(pr if rule.handles_docstrings else code_pr)
            if result is not None:
                pairs.append((rule, result))

        handled: set[str] = set()
        for _, r in pairs:
            handled |= r.handled_files
        # Expose for the coverage tier (Tier 2), which unions over the residual.
        self.pairs = pairs
        self.handled = handled
        rule_reasons = [_rule_reason(rule, r) for rule, r in pairs]

        unhandled = sorted(set(pr.changed_files) - handled)
        if unhandled:
            return SelectionResult(
                scope=None,
                reasons=rule_reasons
                + [{"source": "fallback", "reason": "unhandled_files", "files": unhandled}],
            )

        if not pairs:
            return SelectionResult(
                scope=None,
                reasons=[{"source": "fallback", "reason": "no_rule_contributed"}],
            )

        scope = _combine_scopes([r.scope for _, r in pairs])
        if scope is None:
            # scope=None is a rule's force-fallback signal; attribute it, not a scope conflict.
            forced = sorted({rule.name for rule, r in pairs if r.scope is None})
            if forced:
                fb = {"source": "fallback", "reason": "forced_by_rules", "rules": forced}
            else:
                actionable = sorted({r.scope for _, r in pairs if r.scope and r.scope != "noop"})
                fb = {"source": "fallback", "reason": "scopes_uncombinable", "scopes": actionable}
            return SelectionResult(scope=None, reasons=rule_reasons + [fb])

        affected_stages: set[str] = set()
        for _, r in pairs:
            affected_stages |= r.affected_stages

        # If rules fired but no stages resolved, return scope=None so
        # downstream falls back to baseline. Exception: scope="noop" — the
        # rule explicitly claimed files that need no test stages (e.g. QA
        # test-list edits the pre-merge pipeline doesn't consume), so the
        # empty stage set is intentional and gets preserved through to
        # Groovy Layer 2.
        if not affected_stages and scope != "noop":
            return SelectionResult(
                scope=None,
                reasons=rule_reasons + [{"source": "fallback", "reason": "no_stages_resolved"}],
            )

        # Aggregate per-block prefix->{waive_ids} across rules.
        block_filters: dict[tuple[str, int], dict[str, set[str]]] = {}
        for _, r in pairs:
            for key, prefix_to_waives in r.block_filters.items():
                dst = block_filters.setdefault(key, {})
                for prefix, waives in prefix_to_waives.items():
                    dst.setdefault(prefix, set()).update(waives)

        sanity_required = any(r.sanity_relevant for _, r in pairs)
        perfsanity_required = any(r.perfsanity_relevant for _, r in pairs)

        return SelectionResult(
            scope=scope,
            scopes=sorted({r.scope for _, r in pairs if r.scope}),
            affected_stages=affected_stages,
            reasons=rule_reasons,
            block_filters=block_filters,
            sanity_required=sanity_required,
            perfsanity_required=perfsanity_required,
        )


# --- Input loading ----------------------------------------------------------


def _load_pr_inputs(input_json_path: Path, repo_root: Path) -> PRInputs:
    data = json.loads(input_json_path.read_text())
    # Pre-strip blank- and comment-only `+/-` lines once so every rule
    # sees a "meaningful changes only" diff. Avoids spurious anchor
    # walk-up and stage-select misfires from cosmetic edits.
    # A null diff (PR API omits the patch for binary, rename, or
    # too-large diffs) normalizes to an empty diff.
    raw_diffs = {path: d or "" for path, d in data.get("diffs", {}).items()}
    diffs = {path: strip_noop_diff_lines(diff) for path, diff in raw_diffs.items()}
    docstring_files: set[str] = set()
    docstring_only_files: set[str] = set()
    for path, raw_diff in raw_diffs.items():
        if not path.endswith(".py") or not raw_diff or is_out_of_scope(path):
            continue
        try:
            source = (repo_root / path).read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        executable, changed = split_docstring_diff(source, raw_diff)
        if changed:
            docstring_files.add(path)
            diffs[path] = strip_noop_diff_lines(executable)
            if not any(iter_diff_changes(diffs[path])):
                docstring_only_files.add(path)
    return PRInputs(
        changed_files=list(data.get("changed_files", [])),
        diffs=diffs,
        post_merge=bool(data.get("post_merge", False)),
        raw_diffs=raw_diffs,
        docstring_files=docstring_files,
        docstring_only_files=docstring_only_files,
    )


# --- CLI --------------------------------------------------------------------


@click.command("main", context_settings={"help_option_names": ["-h", "--help"]})
@click.argument("input_json", required=False)
@click.option(
    "--list-needed-diffs",
    "list_needed_diffs",
    is_flag=True,
    help="Print the union of all rules' needs_diff_for patterns and exit.",
)
@click.option(
    "--repo-root",
    default=".",
    help="Path to the TRT-LLM repo root (default: current working directory).",
)
@click.option(
    "--test-db",
    default=None,
    help="Override path to the test-db YAML directory "
    "(default: <repo-root>/tests/integration/test_lists/test-db).",
)
@click.option(
    "--groovy-file",
    default=None,
    help="Override path to the Jenkins test Groovy file "
    "(default: <repo-root>/jenkins/L0_Test.groovy).",
)
@click.option(
    "--coverage-db",
    default=None,
    help="Path to cbts_touchmap.sqlite. When set, the coverage tier (Tier 2) "
    "runs on fallbacks and may drop fully-safe single-GPU stages.",
)
@click.option(
    "--coverage-db-meta",
    default=None,
    help="Path to artifact's --print-selection JSON, describing which DB "
    "--coverage-db is. Its topology and compatibility metadata are recorded.",
)
@click.option(
    "--no-data-policy",
    type=click.Choice(NO_DATA_POLICIES),
    default=DEFAULT_NO_DATA_POLICY,
    help="How to treat a changed function with no rows in the coverage DB: "
    "'file' force-runs every test entering that file, 'importers' only the "
    "file's <module> touch set, 'ignore' treats it as impacting nothing "
    f"(default: {DEFAULT_NO_DATA_POLICY}).",
)
def main(
    input_json,
    list_needed_diffs,
    repo_root,
    test_db,
    groovy_file,
    coverage_db,
    coverage_db_meta,
    no_data_policy,
):
    """CBTS — Change-Based Testing Selection for TRT-LLM CI."""
    args = _Args(
        input_json=input_json,
        list_needed_diffs=list_needed_diffs,
        repo_root=repo_root,
        test_db=test_db,
        groovy_file=groovy_file,
        coverage_db=coverage_db,
        coverage_db_meta=coverage_db_meta,
        no_data_policy=no_data_policy,
    )
    sys.exit(_run(args))


@dataclass
class _Args:
    input_json: Optional[str]
    list_needed_diffs: bool
    repo_root: str
    test_db: Optional[str]
    groovy_file: Optional[str]
    coverage_db: Optional[str]
    coverage_db_meta: Optional[str]
    no_data_policy: str


def _run(args: _Args) -> int:
    if args.list_needed_diffs:
        patterns: set[str] = set(COVERAGE_NEEDS_DIFF_FOR)
        for cls in RULE_CLASSES:
            patterns.update(cls.needs_diff_for)
        for p in sorted(patterns):
            print(p)
        return 0

    if not args.input_json:
        print(
            "error: INPUT_JSON is required (or pass --list-needed-diffs)",
            file=sys.stderr,
        )
        return 2

    input_path = Path(args.input_json)
    if not input_path.is_file():
        print(f"error: INPUT_JSON not found: {input_path}", file=sys.stderr)
        return 2

    repo_root = Path(args.repo_root).resolve()
    test_db_dir = (
        Path(args.test_db) if args.test_db else repo_root / "tests/integration/test_lists/test-db"
    )
    groovy_path = (
        Path(args.groovy_file) if args.groovy_file else repo_root / "jenkins/L0_Test.groovy"
    )

    if not test_db_dir.is_dir():
        print(f"error: test-db directory not found: {test_db_dir}", file=sys.stderr)
        return 2
    if not groovy_path.is_file():
        print(f"error: Jenkins groovy file not found: {groovy_path}", file=sys.stderr)
        return 2

    yaml_index = YAMLIndex.load(test_db_dir)
    # Include post-merge stages; the trigger-mode filter below selects the
    # subset matching the user's flag.
    stages = parse_stages_from_groovy(groovy_path, include_post_merge=True)
    pr = _load_pr_inputs(input_path, repo_root)
    rules = build_rules(yaml_index, stages, repo_root)
    selector = Selector(stages)
    result = selector.run(pr, rules)
    if result.scope is None:
        result.coverage_residual_files, result.coverage_decline_reason = coverage_preflight(
            pr, selector.pairs, selector.handled
        )
        result.coverage_decline_category = _coverage_decline_category(
            result.coverage_decline_reason
        )

    meta = _load_coverage_db_meta(args.coverage_db_meta)
    result.coverage_db_build = meta.get("build")
    result.coverage_db_commit = meta.get("commit")
    result.coverage_db_lag = meta.get("lag")
    result.coverage_db_drift = meta.get("drift")
    result.coverage_db_base_commit = meta.get("base_commit")
    result.coverage_db_drift_status = meta.get("drift_status") or ""
    result.coverage_compatibility = meta.get("patch_apply_status") or "not_attempted"
    result.coverage_decline_reason = (
        meta.get("coverage_decline_reason") or result.coverage_decline_reason
    )
    result.coverage_decline_category = (
        meta.get("coverage_decline_category") or result.coverage_decline_category
    )

    if args.coverage_db and result.scope is None:
        tier = None
        result.coverage_freshness = "ok" if result.coverage_db_drift is not None else "unknown"
        try:
            db = open_db(args.coverage_db)
            tier, note = apply_coverage_tier(
                pr,
                selector.pairs,
                selector.handled,
                stages,
                yaml_index,
                repo_root,
                db,
                no_data_policy=args.no_data_policy,
            )
        except Exception as e:  # noqa: BLE001 — CBTS must never break CI
            note = f"coverage tier errored: {e}"
            tier = None
        if tier is not None:
            result.scope = "coverage"
            result.scopes = sorted(
                {r.scope for _, r in selector.pairs if r.scope and r.scope != "noop"} | {"coverage"}
            )
            result.affected_stages = tier.affected_stages
            result.enable_multi_gpu = True
            result.coverage_dropped_stages = sorted(tier.dropped)
            result.coverage_no_diff_files = int(tier.detail.get("no_diff_files") or 0)
            if tier.removed:
                write_coverage_test_db(
                    src_dir=test_db_dir,
                    out_dir=repo_root / "cbts_test_db",
                    removed=tier.removed,
                )
                result.test_db_dir_override = "cbts_test_db"
                durations = load_durations(repo_root / "tests/integration/defs/.test_durations")
                (
                    result.affected_stage_test_counts,
                    result.affected_stage_split_counts,
                ) = compute_coverage_stage_counts(
                    affected_stages=set(result.affected_stages),
                    stages=stages,
                    yaml_index=yaml_index,
                    removed=tier.removed,
                    durations=durations,
                )
            cov_reason = dict(tier.detail)
            cov_reason["narrowed_stages"] = len(result.affected_stage_split_counts)
            result.reasons = [x for x in result.reasons if x.get("source") != "fallback"] + [
                cov_reason
            ]
        elif note:
            result.coverage_decline_reason = note
            result.coverage_decline_category = _coverage_decline_category(note)
            for x in result.reasons:
                if isinstance(x, dict) and x.get("source") == "fallback":
                    x["coverage_declined"] = note
                    break

    # Layer 3: write narrowed test-db when any block was filtered.
    if result.scope is not None and result.block_filters:
        out_dir_name = "cbts_test_db"
        write_filtered_test_db(
            src_dir=test_db_dir,
            output_dir=repo_root / out_dir_name,
            block_filters=result.block_filters,
        )
        result.test_db_dir_override = out_dir_name
        result.affected_stage_test_counts = compute_stage_test_counts(
            yaml_index=yaml_index,
            stages=stages,
            affected_stages=set(result.affected_stages),
            block_filters=result.block_filters,
        )
        # Size each narrowed stage's split count to ~2h/shard from .test_durations.
        durations = load_durations(repo_root / "tests/integration/defs/.test_durations")
        result.affected_stage_split_counts = compute_stage_split_counts(
            yaml_index=yaml_index,
            stages=stages,
            affected_stages=set(result.affected_stages),
            block_filters=result.block_filters,
            durations=durations,
        )

    # Added before the trigger-mode filter, and outside the counts Layer 2.5 resizes.
    if result.scope is not None:
        result.affected_stages |= {s for s in stages if s.startswith(ALWAYS_RUN_STAGE_PREFIX)}

    # Trigger-mode filter; recompute derived counts. pre-merge drops Post-Merge
    # stages; post-merge keeps both (adds Post-Merge on top, matching baseline).
    pre_filter_stages = set(result.affected_stages)
    if not pr.post_merge:
        result.affected_stages = {s for s in pre_filter_stages if "Post-Merge" not in s}
    result.affected_stage_test_counts = {
        k: v for k, v in result.affected_stage_test_counts.items() if k in result.affected_stages
    }
    result.affected_stage_split_counts = {
        k: v for k, v in result.affected_stage_split_counts.items() if k in result.affected_stages
    }

    _log_decision_to_stderr(stages, result, pr, pre_filter_stages)
    sys.stdout.write(result.to_json())
    return 0


def _log_decision_to_stderr(
    stages: dict[str, Stage],
    result: SelectionResult,
    pr: PRInputs,
    pre_filter_stages: set[str],
) -> None:
    """Print the CBTS decision to stderr for Jenkins console diagnostics."""
    out = sys.stderr
    mode = "post_merge" if pr.post_merge else "pre_merge"
    dropped = sorted(pre_filter_stages - set(result.affected_stages))
    print("=" * 64, file=out)
    print(f"CBTS decision (diagnostic; stderr only) [trigger mode: {mode}]:", file=out)
    print(f"  scope: {result.scope}", file=out)
    print(f"  test_db_dir_override: {result.test_db_dir_override}", file=out)
    if dropped:
        print(
            f"  stages dropped by trigger-mode filter ({len(dropped)}, would run if mode flipped):",
            file=out,
        )
        for s in dropped:
            print(f"    - {s}", file=out)
    if result.reasons:
        print("  reasons:", file=out)
        for r in result.reasons:
            print(f"    - {format_reason(r)}", file=out)
    print(f"  block_filters ({len(result.block_filters)} blocks):", file=out)
    for (yaml_stem, idx), prefix_to_waives in sorted(result.block_filters.items()):
        print(f"    - {yaml_stem}#{idx}:", file=out)
        for prefix, waives in sorted(prefix_to_waives.items()):
            print(f"        {prefix} <- {sorted(waives)}", file=out)
    if result.affected_stage_test_counts:
        print(
            f"  affected_stage_test_counts ({len(result.affected_stage_test_counts)}):",
            file=out,
        )
        for name, count in sorted(result.affected_stage_test_counts.items()):
            split = result.affected_stage_split_counts.get(name)
            split_note = f" -> {split} shard(s)" if split is not None else ""
            print(f"    - {name}: {count}{split_note}", file=out)
    print(f"  affected_stages ({len(result.affected_stages)}):", file=out)
    for name in sorted(result.affected_stages):
        stage = stages.get(name)
        annotation = f" [yaml_stem={stage.yaml_stem}]" if stage else ""
        print(f"    - {name}{annotation}", file=out)
    print("=" * 64, file=out)


if __name__ == "__main__":
    main()

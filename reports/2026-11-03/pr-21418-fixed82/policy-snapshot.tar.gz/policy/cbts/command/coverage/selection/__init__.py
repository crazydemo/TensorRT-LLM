# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""`cbts.command coverage selection ...` subgroup."""

from __future__ import annotations

import click

from cbts.command.coverage.selection import artifact as _artifact
from cbts.command.coverage.selection import audit as _audit
from cbts.command.coverage.selection import explain as _explain


@click.group("selection")
def group() -> None:
    """Tier 2 (coverage-based) selection tools."""


group.add_command(_artifact.main)
group.add_command(_audit.main)
group.add_command(_explain.main)

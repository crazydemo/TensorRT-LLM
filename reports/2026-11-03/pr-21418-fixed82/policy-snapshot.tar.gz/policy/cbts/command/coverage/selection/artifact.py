# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Resolve which post-merge CBTS touch DBs to use.

Candidates are recent builds of `<ARTIFACT_BASE>` with both x86 and SBSA
coverage tarballs. The newest complete pair wins. A squashed PR commit must
cherry-pick cleanly for Tier 2's residual paths at that DB's revision;
otherwise Tier 2 declines. Revision
metadata comes from the forge compare API and needs `GITHUB_API_TOKEN`, the
anonymous quota being per-IP and exhausted by shared CI egress.

The selected architecture DBs are merged locally through the compact coverage
schema, producing the one DB consumed by `cbts.command main`.

Four entry points. `--resolve-pin FILE` reuses or creates the stable build pin
for a PR head. `--resolve-build` prints the newest (or explicitly pinned) build
metadata without checking or downloading the PR diff. `--print-selection` also
checks diff compatibility and stops. `--prepare DIR` downloads, unpacks, and
merges the winner, drops that JSON beside it, and prints the two paths consumed
by CBTS.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import sqlite3
import subprocess
import sys
import tarfile
import tempfile
import urllib.error
import urllib.request
from functools import lru_cache
from pathlib import Path
from typing import Literal, NoReturn, Optional

import click

from cbts.coverage.collection.compact_db import merge_databases

# Merged-artifact base for the main-branch L0_PostMerge job.
ARTIFACT_BASE = "sw-tensorrt-generic/llm-artifacts/LLM/main/L0_PostMerge"
ARCH_TARBALL_NAMES = (
    "cbts_pystart_report_x86_64.tar.gz",
    "cbts_pystart_report_SBSA.tar.gz",
)
# sqlite at the tar root, and the selection JSON `prepare` drops beside it.
DB_NAME = "cbts_touchmap.sqlite"
META_NAME = "cbts_coverage_db.json"
# Per-build metadata carrying `commit=<sha>`; absent on some builds.
BUILD_INFO_NAME = "build_info.txt"

# Stable coverage selection per PR head. Jenkins uploads newly created pin files
# through its Artifactory credential; this module owns lookup, schema, and paths.
PIN_VERSION = 1
PIN_BASE = "sw-tensorrt-generic/llm-artifacts/LLM/main/cbts/coverage-db-pins/v1"
PIN_NAME = "cbts_db_pin.json"

# Branch the DB is collected from; must match ARTIFACT_BASE.
COVERAGE_BRANCH = "main"
# Read by `compare_distance`; the anonymous quota is unusable from shared CI egress IPs.
GITHUB_TOKEN_ENV = "GITHUB_API_TOKEN"
# Authoritative source of the main-branch revisions represented by coverage DBs.
COVERAGE_GIT_REPO = "https://github.com/NVIDIA/TensorRT-LLM.git"

_URM = "https://urm.nvidia.com/artifactory"
_GITHUB_COMPARE = "https://api.github.com/repos/NVIDIA/TensorRT-LLM/compare"
_JENKINS_BASE = "https://prod.blsm.nvidia.com/sw-tensorrt-top-1/job/LLM/job/main/job/L0_PostMerge"

# `build_info.txt` is read with the read helper, jenkins/scripts/fetch_build_artifact.sh, which
# looks for it in the primary artifact location (LLM_ARTIFACTS_PRIMARY) first and in the other one
# only when it is absent there, authenticating to artifactory.nvidia.com with the ARTIFACTORY_NETRC
# file. Coverage archives and pins are read from `_URM` only.
_FETCH_BUILD_ARTIFACT = Path(__file__).resolve().parents[5] / "fetch_build_artifact.sh"
# Exit codes of the read helper that `_fetch_build_artifact` acts on, by the names the helper gives
# them; tests/unittest/scripts/test_fetch_build_artifact.py checks that they match.
_FETCH_ABSENT = 2
_FETCH_REJECTED = 3
_FETCH_TRANSFER_FAILED = 4
# Cover missing or unsuccessful recent builds.
_MAX_PROBE = 50
# Per-request timeout in seconds, for the small JSON/metadata calls.
_TIMEOUT = 15
# Socket timeout for the tarball itself, which runs to hundreds of MB.
_DOWNLOAD_TIMEOUT = 300
# Timeout for local Git operations and the small fetches used by the patch check.
_GIT_TIMEOUT = 120
# Tarball download attempts.
_RETRIES = 3

_PatchApplyStatus = Literal["clean", "conflict", "unknown"]
_COMMIT_RE = re.compile(r"[0-9a-fA-F]{40}")
_PR_NUMBER_RE = re.compile(r"[1-9][0-9]*")


class ArtifactError(Exception):
    """An in-scope build artifact could not be read; the message is written for the job log."""


class ArtifactAuthError(ArtifactError):
    """The read helper exited with FETCH_REJECTED: the primary location rejected the request."""


class ArtifactTransferError(ArtifactError):
    """The read helper exited with FETCH_TRANSFER_FAILED: the transfer failed after its retries."""


def _get(url: str, headers: Optional[dict] = None) -> tuple[Optional[int], Optional[bytes]]:
    req = urllib.request.Request(url, headers=headers or {})
    try:
        with urllib.request.urlopen(req, timeout=_TIMEOUT) as resp:
            return resp.status, resp.read()
    except urllib.error.HTTPError as e:
        return e.code, None
    except OSError as e:
        print(f"[artifact] error fetching {url}: {e}", file=sys.stderr)
        return None, None


def _exists(url: str) -> bool:
    """True if the artifact exists — a 1-byte ranged GET; 200/206 means present."""
    req = urllib.request.Request(url, headers={"Range": "bytes=0-0"})
    try:
        with urllib.request.urlopen(req, timeout=_TIMEOUT) as resp:
            return resp.status in (200, 206)
    except urllib.error.HTTPError:
        return False
    except OSError as e:
        print(f"[artifact] error probing {url}: {e}", file=sys.stderr)
        return False


def latest_build_number(jenkins_base: str = _JENKINS_BASE) -> Optional[int]:
    """Newest build number via the Jenkins REST API (lastBuild, then lastCompletedBuild)."""
    for kind in ("lastBuild", "lastCompletedBuild"):
        status, data = _get(f"{jenkins_base}/{kind}/api/json")
        if status == 200 and data:
            try:
                return int(json.loads(data)["number"])
            except (json.JSONDecodeError, KeyError, ValueError):
                pass
    return None


def tarball_url(build: int, name: str, artifact_base: str = ARTIFACT_BASE) -> str:
    return f"{_URM}/{artifact_base}/{build}/cbts-coverage/{name}"


def tarball_urls(build: int, artifact_base: str = ARTIFACT_BASE) -> list[str]:
    return [tarball_url(build, name, artifact_base) for name in ARCH_TARBALL_NAMES]


# Exceptions for the read helper's failure exit statuses, with what each status means.
_HELPER_FAILURES = {
    _FETCH_REJECTED: (ArtifactAuthError, "the location rejected the request"),
    _FETCH_TRANSFER_FAILED: (ArtifactTransferError, "the transfer failed after retries"),
}


def _fetch_build_artifact(artifact_path: str) -> Optional[bytes]:
    """Content of a build artifact read with the read helper, or None when neither location has it.

    The helper's stdout is discarded, since this command's stdout carries JSON; its stderr, which
    names the location that served the file or says why it could not, goes to the job log.

    Raises:
        ArtifactAuthError: The helper exited with FETCH_REJECTED.
        ArtifactTransferError: The helper exited with FETCH_TRANSFER_FAILED.
        ArtifactError: The helper could not be run, or exited with another status.
    """
    with tempfile.TemporaryDirectory(prefix="cbts-artifact-") as tmp:
        dest = Path(tmp) / Path(artifact_path).name
        try:
            status = subprocess.run(
                ["bash", str(_FETCH_BUILD_ARTIFACT), artifact_path, str(dest)],
                stdout=subprocess.DEVNULL,
                check=False,
            ).returncode
            content = dest.read_bytes() if status == 0 else None
        except OSError as e:
            raise ArtifactError(
                f"{_FETCH_BUILD_ARTIFACT.name} could not read {artifact_path}: {e}"
            ) from e
    if status in (0, _FETCH_ABSENT):
        return content
    error, reason = _HELPER_FAILURES.get(status, (ArtifactError, None))
    detail = f": {reason}" if reason else ""
    raise error(
        f"{_FETCH_BUILD_ARTIFACT.name} could not read {artifact_path}{detail} "
        f"(exit status {status}); its message above says why."
    )


def build_commit(build: int, artifact_base: str = ARTIFACT_BASE) -> Optional[str]:
    """Revision a build ran, from its `build_info.txt`, or None when unavailable.

    A read that fails in transfer counts as unavailable, so `select_tarball` skips that build as it
    skips one without the file. A rejection by the primary location still raises: every other
    build's read would be rejected too. The helper reports a rejection by the secondary location as
    a transfer failure, so that build is skipped.

    While artifactory.nvidia.com is down or unreachable, each read that has to go there fails in
    transfer after the helper's three attempts: about 6 s when it refuses connections or answers
    5xx at once, about 96 s when connections time out, and about 15 min when no data arrives (curl
    ends an attempt after 300 s below 1 byte/s). While it is the primary location (the default),
    every read goes there, so the probe pays that for each build among the last `_MAX_PROBE` whose
    two coverage archives are on urm before the coverage tier declines. After a rollback to urm,
    only builds that urm does not hold are read there, and the probe stops at the newest complete
    build that urm holds. A pre-merge L0_MergeRequest run calls this command in its Setup
    Environment stage, before it starts any build, so its builds wait for these reads.

    Raises:
        ArtifactError: As `_fetch_build_artifact` raises it, except `ArtifactTransferError`;
            `main` reports it and exits 1.
    """
    try:
        data = _fetch_build_artifact(f"{artifact_base}/{build}/{BUILD_INFO_NAME}")
    except ArtifactTransferError as e:
        # The helper's message above says why; the probe moves on to an older build.
        print(f"[artifact] {e}", file=sys.stderr)
        return None
    if not data:
        return None
    for line in data.decode("utf-8", "replace").splitlines():
        key, _, value = line.partition("=")
        if key.strip() == "commit" and value.strip():
            return value.strip()
    return None


def _pin_decline(reason: str) -> dict:
    """Return a machine-readable, fail-closed pin resolution result."""
    return {
        "status": "declined",
        "compatibility": "unknown",
        "decline_reason": f"coverage tier declined: {reason}",
        "pin_upload_required": False,
    }


def _valid_pin(pin: object, pr_number: str, pr_head: str) -> bool:
    """Whether an Artifactory pin matches this PR identity and schema."""
    if not isinstance(pin, dict):
        return False
    build = pin.get("coverage_db_build")
    commit = pin.get("coverage_db_commit")
    return (
        pin.get("version") == PIN_VERSION
        and str(pin.get("pr_number")) == pr_number
        and pin.get("pr_head") == pr_head
        and type(build) is int
        and build > 0
        and isinstance(commit, str)
        and _COMMIT_RE.fullmatch(commit) is not None
    )


def resolve_pin(
    pin_path: str,
    pr_number: str,
    pr_head: str,
    pr_base_commit: str,
) -> dict:
    """Reuse a PR-head coverage pin or create the local file Jenkins must upload."""
    if _PR_NUMBER_RE.fullmatch(pr_number) is None or _COMMIT_RE.fullmatch(pr_head) is None:
        return _pin_decline("invalid PR identity for coverage DB pin")
    target = f"{PIN_BASE}/{pr_number}/{pr_head}/"
    status, data = _get(f"{_URM}/{target}{PIN_NAME}")
    if status == 200:
        try:
            pin = json.loads(data) if data else None
        except (UnicodeDecodeError, json.JSONDecodeError):
            pin = None
        if not _valid_pin(pin, pr_number, pr_head):
            return _pin_decline("invalid coverage DB pin")
        assert isinstance(pin, dict)
        return {
            "status": "ready",
            "build": pin["coverage_db_build"],
            "commit": pin["coverage_db_commit"],
            "pin_upload_required": False,
        }
    if status != 404:
        return _pin_decline("coverage DB pin query failed")

    selected = select_tarball(pr_base_commit)
    if selected is None:
        return _pin_decline("coverage DB could not be resolved")
    build = selected.get("build")
    commit = selected.get("commit")
    if (
        type(build) is not int
        or build <= 0
        or not isinstance(commit, str)
        or _COMMIT_RE.fullmatch(commit) is None
    ):
        return _pin_decline("selected coverage DB metadata invalid")

    pin = {
        "version": PIN_VERSION,
        "pr_number": pr_number,
        "pr_head": pr_head,
        "coverage_db_build": build,
        "coverage_db_commit": commit,
    }
    try:
        output = Path(pin_path)
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps(pin))
    except OSError as e:
        print(f"[artifact] coverage DB pin could not be written: {e}", file=sys.stderr)
        return _pin_decline("coverage DB pin could not be written")
    return {
        "status": "ready",
        "build": build,
        "commit": commit,
        "pin_upload_required": True,
        "pin_path": pin_path,
        "pin_target": target,
    }


@lru_cache(maxsize=None)
def _compare(base: str, head: str) -> Optional[dict]:
    """The forge's `base...head` compare payload, or None when it cannot be had."""
    headers = {"Accept": "application/vnd.github+json"}
    token = os.environ.get(GITHUB_TOKEN_ENV)
    if token:
        headers["Authorization"] = f"Bearer {token}"
    status, data = _get(f"{_GITHUB_COMPARE}/{base}...{head}", headers)
    if status != 200 or not data:
        # 403 without a token means the shared egress IP burned the 60/h anonymous quota.
        hint = " (no token: anonymous quota)" if status == 403 and not token else ""
        print(
            f"[artifact] compare {base[:10]}...{head[:10]} failed: HTTP {status}{hint}",
            file=sys.stderr,
        )
        return None
    try:
        return json.loads(data)
    except json.JSONDecodeError as e:
        print(f"[artifact] compare {base[:10]}...{head[:10]}: bad response: {e}", file=sys.stderr)
        return None


def compare_distance(commit: str, branch: str = COVERAGE_BRANCH) -> Optional[int]:
    """Commits `branch` gained since `commit` — reporting only; never negative."""
    payload = _compare(commit, branch)
    if payload is None:
        return None
    try:
        # `ahead_by` counts the full range; only the `commits` array is truncated at 250.
        return int(payload["ahead_by"])
    except (KeyError, TypeError, ValueError) as e:
        print(f"[artifact] compare {commit[:10]}...{branch}: no ahead_by: {e}", file=sys.stderr)
        return None


def merge_base(head: str, branch: str = COVERAGE_BRANCH) -> Optional[str]:
    """The commit `head` forked from `branch` — the revision the PR's diff is against."""
    payload = _compare(branch, head)
    if payload is None:
        return None
    sha = (payload.get("merge_base_commit") or {}).get("sha")
    if not sha:
        print(f"[artifact] compare {branch}...{head[:10]}: no merge_base_commit", file=sys.stderr)
        return None
    return sha


def drift(db_commit: str, base_commit: str) -> tuple[Optional[int], str]:
    """Distance from the DB's revision to the PR's base; direction is recorded, not weighted."""
    payload = _compare(db_commit, base_commit)
    if payload is None:
        return None, "unknown"
    try:
        distance = int(payload["ahead_by"]) + int(payload["behind_by"])
        return distance, str(payload.get("status") or "")
    except (KeyError, TypeError, ValueError) as e:
        print(
            f"[artifact] compare {db_commit[:10]}...{base_commit[:10]}: no ahead/behind: {e}",
            file=sys.stderr,
        )
        return None, "unknown"


def _run_git(
    args: list[str],
    *,
    cwd: Path,
    input_data: Optional[bytes] = None,
    env: Optional[dict[str, str]] = None,
    timeout: int = _GIT_TIMEOUT,
) -> Optional[subprocess.CompletedProcess[bytes]]:
    try:
        return subprocess.run(
            ["git", *args],
            cwd=cwd,
            input=input_data,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=env,
            check=False,
            timeout=timeout,
        )
    except subprocess.TimeoutExpired:
        command = args[0] if args else "command"
        print(f"[artifact] git {command} timed out after {timeout}s", file=sys.stderr)
        return None


def _patch_apply_status(
    pr_base_commit: str,
    pr_head: str,
    db_commit: str,
    repo_root: Path = Path("."),
    upstream_url: Optional[str] = None,
    relevant_paths: Optional[list[str]] = None,
) -> _PatchApplyStatus:
    """Check the relevant paths of a squashed PR commit against the DB revision."""
    repo_source = repo_root.resolve()
    main_repo = upstream_url or COVERAGE_GIT_REPO
    checked_out_head = _run_git(["rev-parse", "HEAD"], cwd=repo_source)
    if (
        checked_out_head is None
        or checked_out_head.returncode != 0
        or checked_out_head.stdout.decode("ascii", "replace").strip() != pr_head
    ):
        print(f"[artifact] checked-out revision is not PR head {pr_head[:10]}", file=sys.stderr)
        return "unknown"
    with tempfile.TemporaryDirectory(prefix="cbts_patch_check_") as temp_dir:
        temp = Path(temp_dir)
        repo = temp / "repo"
        initialized = _run_git(["init", str(repo)], cwd=temp)
        if initialized is None or initialized.returncode != 0:
            print("[artifact] could not initialize the patch-check repository", file=sys.stderr)
            return "unknown"

        # The PR head is guaranteed to be the checked-out revision. The base and coverage
        # commits come from the authoritative upstream repository.
        fetched_head = _run_git(
            ["fetch", "--no-tags", "--depth=1", str(repo_source), "HEAD"], cwd=repo
        )
        if fetched_head is None or fetched_head.returncode != 0:
            print(
                f"[artifact] could not load PR head {pr_head[:10]} for patch check",
                file=sys.stderr,
            )
            return "unknown"

        revisions = list(dict.fromkeys((pr_base_commit, db_commit)))
        fetched_revisions = _run_git(
            ["fetch", "--no-tags", "--depth=1", main_repo, *revisions], cwd=repo
        )
        if fetched_revisions is None or fetched_revisions.returncode != 0:
            print(
                "[artifact] could not load the base/coverage revisions for patch check",
                file=sys.stderr,
            )
            return "unknown"

        checked_out_db = _run_git(["checkout", "--detach", db_commit], cwd=repo)
        if checked_out_db is None or checked_out_db.returncode != 0:
            print("[artifact] could not check out the coverage revision", file=sys.stderr)
            return "unknown"

        squashed_pr = _run_git(
            [
                "-c",
                "user.name=CBTS",
                "-c",
                "user.email=cbts@nvidia.com",
                "commit-tree",
                f"{pr_head}^{{tree}}",
                "-p",
                pr_base_commit,
                "-m",
                "squashed PR for CBTS compatibility check",
            ],
            cwd=repo,
        )
        if squashed_pr is None or squashed_pr.returncode != 0:
            print("[artifact] could not create the squashed PR commit", file=sys.stderr)
            return "unknown"

        pr_commit = squashed_pr.stdout.decode("ascii", "replace").strip()
        applied = _run_git(["cherry-pick", "--no-commit", pr_commit], cwd=repo)
        if applied is None:
            return "unknown"
        if applied.returncode == 0:
            return "clean"
        if relevant_paths is None:
            return "conflict"
        unmerged = _run_git(
            ["diff", "--name-only", "--diff-filter=U", "-z"],
            cwd=repo,
        )
        if unmerged is None or unmerged.returncode != 0:
            return "unknown"
        conflict_paths = {
            path.decode("utf-8", "surrogateescape") for path in unmerged.stdout.split(b"\0") if path
        }
        if not conflict_paths:
            return "unknown"
        relevant_conflicts = conflict_paths.intersection(relevant_paths)
        if relevant_conflicts:
            return "conflict"
        print(
            "[artifact] ignoring conflict(s) outside the Tier-2 residual: "
            + ", ".join(sorted(conflict_paths)),
            file=sys.stderr,
        )
        return "clean"


def _selection_accepts_pr_diff(
    sel: dict,
    pr_base_commit: str,
    pr_head: str,
    relevant_paths: Optional[list[str]] = None,
) -> bool:
    sel["patch_apply_status"] = _patch_apply_status(
        pr_base_commit,
        pr_head,
        sel["commit"],
        relevant_paths=relevant_paths,
    )
    if sel["patch_apply_status"] == "clean":
        sel["coverage_decline_reason"] = ""
        sel["coverage_decline_category"] = ""
        return True
    sel["coverage_decline_reason"] = (
        "coverage tier declined: Tier-2 residual does not apply cleanly to "
        f"selected DB commit {sel['commit'][:10]} ({sel['patch_apply_status']})"
    )
    sel["coverage_decline_category"] = f"compatibility_{sel['patch_apply_status']}"
    print(f"[artifact] {sel['coverage_decline_reason']}", file=sys.stderr)
    return False


def select_tarball(
    pr_base_commit: str,
    artifact_base: str = ARTIFACT_BASE,
    jenkins_base: str = _JENKINS_BASE,
    max_probe: int = _MAX_PROBE,
) -> Optional[dict]:
    """Newest complete architecture pair with measurable PR-base topology."""
    build = latest_build_number(jenkins_base)
    if build is None:
        print("[artifact] could not resolve latest build number", file=sys.stderr)
        return None
    unknown_commits = 0
    for b in range(build, max(0, build - max_probe), -1):
        urls = tarball_urls(b, artifact_base)
        if not all(_exists(url) for url in urls):
            continue
        commit = build_commit(b, artifact_base)
        if not commit:
            print(f"[artifact] build {b}: commit unknown; skipped", file=sys.stderr)
            unknown_commits += 1
            continue
        distance, status = drift(commit, pr_base_commit)
        if distance is None:
            print(
                f"[artifact] latest complete build {b}: topology against the PR base unknown",
                file=sys.stderr,
            )
            return None
        if status not in ("ahead", "behind", "identical"):
            print(
                f"[artifact] latest complete build {b}: relation to the PR base is "
                f"{status or 'unknown'}",
                file=sys.stderr,
            )
            return None
        selected = {
            "url": urls[0],
            "urls": urls,
            "build": b,
            "commit": commit,
            "base_commit": pr_base_commit,
            "drift": distance,
            "drift_status": status,
            "lag": compare_distance(commit),
        }
        if selected["lag"] is None:
            print(f"[artifact] build {b}: lag behind main unknown", file=sys.stderr)
        return selected
    skipped = f" ({unknown_commits} skipped: commit unknown)" if unknown_commits else ""
    print(
        "[artifact] no complete x86/SBSA coverage pair with a known commit in the last "
        f"{max_probe} builds{skipped}",
        file=sys.stderr,
    )
    return None


def select_build(
    build: int,
    pr_base_commit: str,
    expected_commit: Optional[str] = None,
    artifact_base: str = ARTIFACT_BASE,
) -> Optional[dict]:
    """Resolve and validate one explicitly pinned coverage build."""
    urls = tarball_urls(build, artifact_base)
    if not all(_exists(url) for url in urls):
        print(f"[artifact] pinned build {build}: coverage pair is incomplete", file=sys.stderr)
        return None
    commit = build_commit(build, artifact_base)
    if not commit:
        print(f"[artifact] pinned build {build}: commit unknown", file=sys.stderr)
        return None
    if expected_commit is not None and commit != expected_commit:
        print(
            f"[artifact] pinned build {build}: commit changed from {expected_commit} to {commit}",
            file=sys.stderr,
        )
        return None
    distance, status = drift(commit, pr_base_commit)
    if distance is None:
        print(
            f"[artifact] pinned build {build}: topology against the PR base unknown",
            file=sys.stderr,
        )
        return None
    if status not in ("ahead", "behind", "identical"):
        print(
            f"[artifact] pinned build {build}: relation to the PR base is {status or 'unknown'}",
            file=sys.stderr,
        )
        return None
    return {
        "url": urls[0],
        "urls": urls,
        "build": build,
        "commit": commit,
        "base_commit": pr_base_commit,
        "drift": distance,
        "drift_status": status,
        "lag": compare_distance(commit),
    }


def describe(sel: dict) -> str:
    """One-line account of the selection, for the CI log."""
    lag = "unknown" if sel.get("lag") is None else f"+{sel['lag']} commit(s)"
    if sel.get("drift") is None:
        base_distance = "unknown"
    else:
        base_distance = f"+{sel['drift']} commit(s)"
    base = (sel.get("base_commit") or "unknown")[:10]
    return (
        f"[artifact] selected build {sel.get('build')}, "
        f"DB commit {(sel.get('commit') or 'unknown')[:10]}; topology from DB: "
        f"PR base {base} ({base_distance}), current main tip ({lag}); "
        f"PR diff compatibility: {sel.get('patch_apply_status', 'unknown')}"
    )


def download(url: str, dest: Path, attempts: int = _RETRIES) -> Optional[Path]:
    """Stream the tarball into `dest`, retrying; None when every attempt fails.

    Streamed, not buffered: the artifact runs to hundreds of MB.
    """
    out = dest / url.rsplit("/", maxsplit=1)[-1]
    for attempt in range(1, attempts + 1):
        try:
            with (
                urllib.request.urlopen(url, timeout=_DOWNLOAD_TIMEOUT) as resp,
                out.open("wb") as f,
            ):
                shutil.copyfileobj(resp, f)
            return out
        except OSError as e:  # HTTPError/URLError are OSError subclasses
            print(f"[artifact] download {attempt}/{attempts} failed: {e}", file=sys.stderr)
    return None


def extract(tarball: Path, dest: Path) -> bool:
    """Unpack the tarball into `dest`; False when it is not readable."""
    try:
        with tarfile.open(tarball, "r:gz") as tf:
            # `filter` lands in 3.12 and is the default from 3.14; older runtimes lack it.
            if sys.version_info >= (3, 12):
                tf.extractall(dest, filter="data")
            else:
                tf.extractall(dest)
    except (OSError, tarfile.TarError) as e:
        print(f"[artifact] extract failed: {e}", file=sys.stderr)
        return False
    return True


def prepare(
    dest_dir: str,
    pr_head: Optional[str],
    relevant_paths: list[str],
    build: Optional[int] = None,
    expected_commit: Optional[str] = None,
) -> Optional[dict]:
    """Resolve, download, and merge the DB pair; `{path, meta}` or None on failure.

    `meta` is the selection JSON on disk, which `cbts.command main --coverage-db-meta` reads.
    Paths are relative to the caller's cwd, matching the Groovy caller's `cd ${LLM_ROOT}`.
    """
    if not pr_head:
        print("[artifact] PR head is required to select a coverage DB", file=sys.stderr)
        return None
    pr_base_commit = merge_base(pr_head)
    if not pr_base_commit:
        print("[artifact] could not resolve the PR base commit", file=sys.stderr)
        return None
    sel = (
        select_build(build, pr_base_commit, expected_commit=expected_commit)
        if build is not None
        else select_tarball(pr_base_commit)
    )
    if sel is None:
        return None
    compatible = _selection_accepts_pr_diff(
        sel,
        pr_base_commit,
        pr_head,
        relevant_paths,
    )
    print(describe(sel), file=sys.stderr)

    dest = Path(dest_dir)
    dest.mkdir(parents=True, exist_ok=True)
    meta = dest / META_NAME
    meta.write_text(json.dumps(sel))
    if not compatible:
        return {"path": None, "meta": str(meta)}

    db = dest / DB_NAME
    with tempfile.TemporaryDirectory(prefix="cbts_artifacts_", dir=dest) as temp_dir:
        temp = Path(temp_dir)
        source_dbs = []
        for index, url in enumerate(sel["urls"]):
            tarball = download(url, temp)
            artifact_dir = temp / str(index)
            artifact_dir.mkdir()
            if tarball is None or not extract(tarball, artifact_dir):
                return None
            source_db = artifact_dir / DB_NAME
            if not source_db.is_file():
                print(f"[artifact] {DB_NAME} not in {url}", file=sys.stderr)
                return None
            source_dbs.append(source_db)
        try:
            connection = merge_databases(source_dbs, db)
        except (OSError, sqlite3.Error, ValueError) as e:
            print(f"[artifact] merge failed: {e}", file=sys.stderr)
            return None
        connection.close()

    return {"path": str(db), "meta": str(meta)}


def _load_paths_json(path: Optional[str]) -> Optional[list[str]]:
    """Load the non-empty JSON list of repository-relative Tier-2 paths."""
    if not path:
        return None
    try:
        data = json.loads(Path(path).read_text())
    except (OSError, json.JSONDecodeError) as e:
        print(f"[artifact] residual paths unreadable ({path}): {e}", file=sys.stderr)
        return None
    if not isinstance(data, list) or not data or not all(isinstance(item, str) for item in data):
        print("[artifact] residual paths must be a non-empty JSON string list", file=sys.stderr)
        return None
    return sorted(set(data))


@click.command("artifact", context_settings={"help_option_names": ["-h", "--help"]})
@click.option(
    "--resolve-pin",
    "resolve_pin_file",
    metavar="FILE",
    default=None,
    help="reuse a PR-head build pin or write a new pin to FILE for Jenkins upload",
)
@click.option(
    "--resolve-build",
    "resolve_build",
    is_flag=True,
    help="resolve and print build metadata without checking or downloading the PR diff",
)
@click.option(
    "--print-selection",
    "print_selection",
    is_flag=True,
    help="resolve and print {urls, build, commit, lag, base_commit, drift, "
    "drift_status, patch_apply_status} as JSON",
)
@click.option("--build", type=int, default=None, help="pin a build number (skip auto-resolve)")
@click.option(
    "--expected-commit",
    default=None,
    help="require an explicitly pinned build to retain this coverage commit",
)
@click.option(
    "--prepare",
    "prepare_dir",
    metavar="DIR",
    default=None,
    help="resolve, validate, download and merge the architecture DBs into DIR, then "
    "print {path, meta} as JSON",
)
@click.option(
    "--pr-head",
    default=None,
    help="required PR head revision; its merge base measures DB drift and defines "
    "the diff checked against the selected coverage revision",
)
@click.option(
    "--pr-number",
    default=None,
    help="PR number used by --resolve-pin to address the stable Artifactory path",
)
@click.option(
    "--paths-json",
    default=None,
    help="JSON list of Tier-2 residual paths; required for the compatibility check",
)
def main(
    resolve_pin_file,
    resolve_build,
    print_selection,
    build,
    expected_commit,
    prepare_dir,
    pr_head,
    pr_number,
    paths_json,
):
    """Resolve which post-merge CBTS touch DBs to use."""
    if (
        sum((resolve_pin_file is not None, resolve_build, print_selection, prepare_dir is not None))
        != 1
    ):
        raise click.UsageError(
            "exactly one of --resolve-pin / --resolve-build / --print-selection / "
            "--prepare is required"
        )
    if expected_commit is not None and build is None:
        raise click.UsageError("--expected-commit requires --build")
    try:
        _run_entry_point(
            resolve_pin_file,
            resolve_build,
            build,
            expected_commit,
            prepare_dir,
            pr_head,
            pr_number,
            paths_json,
        )
    except ArtifactError as e:
        # Reported like the other failures: a message on stderr, no JSON, exit status 1.
        for line in str(e).splitlines():
            print(f"[artifact] {line}", file=sys.stderr)
        sys.exit(1)


def _run_entry_point(
    resolve_pin_file: Optional[str],
    resolve_build: bool,
    build: Optional[int],
    expected_commit: Optional[str],
    prepare_dir: Optional[str],
    pr_head: Optional[str],
    pr_number: Optional[str],
    paths_json: Optional[str],
) -> NoReturn:
    """Run the entry point `main` selected and exit with its status."""
    if prepare_dir:
        relevant_paths = _load_paths_json(paths_json)
        if relevant_paths is None:
            sys.exit(1)
        ready = prepare(
            prepare_dir,
            pr_head,
            relevant_paths,
            build=build,
            expected_commit=expected_commit,
        )
        if ready is None:
            sys.exit(1)
        print(json.dumps(ready))
        sys.exit(0)

    if not pr_head:
        print("[artifact] --pr-head is required", file=sys.stderr)
        sys.exit(1)
    pr_base_commit = merge_base(pr_head)
    if not pr_base_commit:
        sys.exit(1)

    if resolve_pin_file is not None:
        if not pr_number:
            print("[artifact] --pr-number is required by --resolve-pin", file=sys.stderr)
            sys.exit(1)
        print(
            json.dumps(
                resolve_pin(
                    resolve_pin_file,
                    str(pr_number),
                    pr_head,
                    pr_base_commit,
                )
            )
        )
        sys.exit(0)

    if build is not None:
        best = select_build(
            build,
            pr_base_commit,
            expected_commit=expected_commit,
        )
    else:
        best = select_tarball(pr_base_commit)
    if best is None:
        sys.exit(1)
    if resolve_build:
        print(json.dumps(best))
        sys.exit(0)

    relevant_paths = _load_paths_json(paths_json)
    if relevant_paths is None:
        sys.exit(1)
    if not _selection_accepts_pr_diff(best, pr_base_commit, pr_head, relevant_paths):
        sys.exit(1)
    print(json.dumps(best))
    sys.exit(0)

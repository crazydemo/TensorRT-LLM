#!/usr/bin/env python3
# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
r"""CBTS dry-run debug tool.

Replays CBTS over historical commits and writes per-PR artifacts (summary
+ filtered test-db YAMLs) plus a top-level INDEX.md, so the rule set can
be inspected without firing real CI.

Each commit is replayed with its own snapshot of
`tests/integration/test_lists/test-db/` and `jenkins/L0_Test.groovy`
(extracted via `git show`), so the result reflects what CBTS would have
decided at the time the PR landed.

Examples:
--------
Reproduce `cbts_dryrun/` (tests-only PRs in the last 500 commits)::

    PYTHONPATH=jenkins/scripts/cbts python3 -m cbts.command dryrun \\
        --window 500 --filter tests-only --out cbts_dryrun

Reproduce `cbts_dryrun_recent10/` (last 10 commits, any kind)::

    PYTHONPATH=jenkins/scripts/cbts python3 -m cbts.command dryrun \\
        --window 10 --filter all --out cbts_dryrun_recent10

Single commit by SHA (debug a specific PR)::

    PYTHONPATH=jenkins/scripts/cbts python3 -m cbts.command dryrun \\
        --sha 219559c --out /tmp/cbts_one

Cumulative diff of a commit range as one CBTS run (mirrors a whole-PR
diff rather than replaying each commit separately)::

    PYTHONPATH=jenkins/scripts/cbts python3 -m cbts.command dryrun \\
        --range origin/main...HEAD --out /tmp/cbts_range

Coverage tier (Tier 2) is OFF by default. To include coverage-based selection
(merged with the rules by `cbts.command main`), download the post-merge touch
DB and pass `--coverage-db`::

    PYTHONPATH=jenkins/scripts/cbts python3 -m cbts.command dryrun \\
        --window 40 --filter all --coverage-db /path/to/cbts_touchmap.sqlite
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Optional

import click

THIS_FILE = Path(__file__).resolve()
# jenkins/scripts/cbts/cbts/command/dryrun.py -> jenkins/scripts/cbts (outer vendor dir);
# put on PYTHONPATH for the `cbts.command main` subprocess below.
CBTS_OUTER_DIR = THIS_FILE.parents[2]
DEFAULT_REPO_ROOT = THIS_FILE.parents[5]  # repo root

TEST_DB_REL = "tests/integration/test_lists/test-db"
GROOVY_REL = "jenkins/L0_Test.groovy"
PR_RE = re.compile(r"\(#(\d+)\)\s*$")


# --- git helpers ------------------------------------------------------------


def _git(repo: Path, *args: str, check: bool = True) -> subprocess.CompletedProcess:
    return subprocess.run(
        ["git", *args],
        cwd=str(repo),
        capture_output=True,
        text=True,
        check=check,
    )


def _list_changed_files(repo: Path, sha: str) -> list[str]:
    out = _git(repo, "show", "--name-only", "--pretty=format:", sha).stdout
    return [ln for ln in out.splitlines() if ln.strip()]


def _file_diff(repo: Path, sha: str, path: str) -> str:
    return _git(repo, "diff", f"{sha}^", sha, "--", path, check=False).stdout


def _split_range(expr: str) -> tuple[str, str, str]:
    """Split a git range into (base, tip, diff_arg).

    Supports 'A..B' (endpoint diff), 'A...B' (merge-base diff), and a bare
    'A' (treated as A^..A, the single-commit diff). `diff_arg` is passed
    verbatim to `git diff`, preserving two- vs three-dot semantics; an empty
    side defaults to HEAD, matching git's own range parsing.
    """
    for sep in ("...", ".."):
        if sep in expr:
            left, right = expr.split(sep, 1)
            return (left or "HEAD"), (right or "HEAD"), expr
    return f"{expr}^", expr, f"{expr}^..{expr}"


def _list_changed_files_range(repo: Path, diff_arg: str) -> list[str]:
    out = _git(repo, "diff", "--name-only", diff_arg).stdout
    return [ln for ln in out.splitlines() if ln.strip()]


def _file_diff_range(repo: Path, diff_arg: str, path: str) -> str:
    return _git(repo, "diff", diff_arg, "--", path, check=False).stdout


def _resolve_pr(subject: str, sha: str) -> tuple[str, str]:
    m = PR_RE.search(subject)
    if m:
        pr = m.group(1)
        return f"pr-{pr}", f"https://github.com/NVIDIA/TensorRT-LLM/pull/{pr}"
    return f"sha-{sha[:8]}", f"(no PR number; sha={sha})"


# --- run `cbts.command main` -------------------------------------------------


def _run_cbts(
    payload: dict, test_db: Path, groovy: Path, repo: Path, coverage_db: Optional[str] = None
) -> dict:
    """Invoke `cbts.command main` as a subprocess against one payload and parse its decision JSON.

    Always targets the current checkout's `cbts` package (not the replayed worktree's), so a
    replay evaluates today's rules against a historical diff, not historical rules.
    """
    with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as f:
        json.dump(payload, f)
        path = f.name
    argv = [
        sys.executable,
        "-m",
        "cbts.command",
        "main",
        path,
        "--repo-root",
        str(repo),
        "--test-db",
        str(test_db),
        "--groovy-file",
        str(groovy),
    ]
    env = dict(os.environ, PYTHONPATH=str(CBTS_OUTER_DIR))
    if coverage_db:
        argv += ["--coverage-db", coverage_db]
    try:
        res = subprocess.run(argv, capture_output=True, text=True, check=False, env=env)
    finally:
        os.unlink(path)
    if res.returncode != 0:
        return {"_error": res.stderr.strip(), "_returncode": res.returncode}
    try:
        return json.loads(res.stdout)
    except json.JSONDecodeError:
        return {"_error": "non-json stdout", "_stdout": res.stdout[:1000]}


# --- formatting -------------------------------------------------------------


def _fmt_summary(
    pr_url: str,
    sha: str,
    subject: str,
    files: list[str],
    result: dict,
    post_merge: bool,
    tests_only: bool,
) -> str:
    trigger = "/bot run --post-merge" if post_merge else "/bot run"
    lines = [
        f"PR:                {pr_url}",
        f"Subject:           {subject}",
        f"SHA:               {sha}",
        f"Trigger:           {trigger} (post_merge={post_merge})",
        f"Tests-only:        {tests_only}",
        f"Files changed ({len(files)}):",
    ]
    lines.extend(f"  - {f}" for f in files)
    lines.append("")
    if "_error" in result:
        lines.append(f"ERROR: {result['_error']}")
        return "\n".join(lines) + "\n"
    scope = result.get("scope")
    lines.append(f"scope:                {scope!r}")
    lines.append(f"scopes:               {result.get('scopes', [])}")
    lines.append(f"sanity_required:      {result.get('sanity_required')}")
    lines.append(f"perfsanity_required:  {result.get('perfsanity_required')}")
    lines.append(f"coverage_compatibility: {result.get('coverage_compatibility')}")
    lines.append(f"coverage_decline_category: {result.get('coverage_decline_category')!r}")
    lines.append(f"coverage_decline_reason: {result.get('coverage_decline_reason')!r}")
    residual = result.get("coverage_residual_files", [])
    lines.append(f"coverage_residual_files ({len(residual)}):")
    lines.extend(f"  - {path}" for path in residual)
    override = result.get("test_db_dir_override")
    lines.append(f"test_db_dir_override: {override!r}")
    stages = result.get("affected_stages", [])
    lines.append(f"affected_stages ({len(stages)}):")
    lines.extend(f"  - {s}" for s in stages)
    counts = result.get("affected_stage_test_counts", {})
    splits = result.get("affected_stage_split_counts", {})
    if splits:
        lines.append(f"split sizing ({len(splits)} stages, kept_entries -> shards):")
        for s in sorted(splits):
            lines.append(f"  - {s}: {counts.get(s, '?')} -> {splits[s]}")
    dropped = result.get("coverage_dropped_stages", [])
    if dropped:
        lines.append(f"coverage dropped stages ({len(dropped)}, emptied -> not run):")
        lines.extend(f"  - {s}" for s in dropped)
    lines.append("reasons:")
    for r in result.get("reasons", []):
        if isinstance(r, dict):
            src = r.get("source", "?")
            rest = ", ".join(f"{k}={v}" for k, v in r.items() if k != "source")
            lines.append(f"  - [{src}] {rest}" if rest else f"  - [{src}]")
        else:
            lines.append(f"  - {r}")
    return "\n".join(lines) + "\n"


def _index_row(label: str, pr_url: str, files: list[str], subject: str, result: dict) -> str:
    if "_error" in result:
        return (
            f"| [{label}](./{label}/) | `ERROR` | - | - | - | - | {len(files)} | "
            f"[link]({pr_url}) | {subject[:70]} |"
        )
    scope = result.get("scope")
    scope_disp = f"`{scope}`" if scope else "`None`"
    n_stages = len(result.get("affected_stages", []))
    n_yamls = len(result.get("affected_stage_test_counts", {})) or n_stages
    sanity = "Y" if result.get("sanity_required") else "n"
    perf = "Y" if result.get("perfsanity_required") else "n"
    short = subject[:70] + ("…" if len(subject) > 70 else "")
    return (
        f"| [{label}](./{label}/) | {scope_disp} | {n_stages} | {n_yamls} | "
        f"{sanity} | {perf} | {len(files)} | [link]({pr_url}) | {short} |"
    )


# --- commit discovery -------------------------------------------------------


def _walk_commits(repo: Path, ref: str, window: int) -> list[str]:
    out = _git(repo, "log", ref, f"-{window}", "--pretty=format:%H").stdout
    return [ln for ln in out.splitlines() if ln.strip()]


def _is_tests_only(files: list[str]) -> bool:
    return bool(files) and all(f.startswith("tests/") for f in files)


# --- main loop --------------------------------------------------------------


def _prep_pr_dir(out_dir: Path, label: str) -> Path:
    """Create out_dir/label and wipe stale artifacts (keeping summary.txt)."""
    pr_dir = out_dir / label
    pr_dir.mkdir(parents=True, exist_ok=True)
    for old in pr_dir.iterdir():
        if old.name == "summary.txt":
            continue
        if old.is_dir():
            shutil.rmtree(old)
        else:
            old.unlink()
    return pr_dir


def _cbts_for_snapshot(
    repo: Path,
    tip_sha: str,
    files: list[str],
    diffs: dict[str, str],
    post_merge: bool,
    pr_dir: Path,
    coverage_db: Optional[str] = None,
) -> dict:
    """Run CBTS against the tree at `tip_sha` over `files`/`diffs`.

    Materializes `tip_sha` as a detached worktree so every path CBTS reads
    (post-change YAML, .py source, accuracy refs) is the end-state of the
    commit/range, not whatever HEAD is now. Copies any filtered test-db
    YAMLs into `pr_dir` before the worktree is torn down.
    """
    if not files:
        return {"_error": "no files changed"}
    payload = {"changed_files": files, "diffs": diffs, "post_merge": post_merge}
    with tempfile.TemporaryDirectory() as td:
        wt = Path(td) / "wt"
        _git(repo, "worktree", "add", "--detach", str(wt), tip_sha)
        try:
            test_db = wt / TEST_DB_REL
            groovy = wt / GROOVY_REL
            shared_out = wt / "cbts_test_db"
            result = _run_cbts(payload, test_db, groovy, wt, coverage_db)
            if shared_out.exists():
                for yml in shared_out.glob("*.yml"):
                    shutil.copy2(yml, pr_dir / yml.name)
        finally:
            _git(repo, "worktree", "remove", "--force", str(wt), check=False)
    return result


def _replay_one(
    repo: Path,
    sha: str,
    out_dir: Path,
    post_merge: bool,
    coverage_db: Optional[str] = None,
) -> tuple[str, str, list[str], str, dict, bool]:
    subject = _git(repo, "log", "-1", "--pretty=%s", sha).stdout.strip()
    label, pr_url = _resolve_pr(subject, sha)
    files = _list_changed_files(repo, sha)
    tests_only = _is_tests_only(files)
    pr_dir = _prep_pr_dir(out_dir, label)
    diffs = {f: _file_diff(repo, sha, f) for f in files}
    result = _cbts_for_snapshot(repo, sha, files, diffs, post_merge, pr_dir, coverage_db)
    (pr_dir / "summary.txt").write_text(
        _fmt_summary(pr_url, sha, subject, files, result, post_merge, tests_only)
    )
    return label, pr_url, files, subject, result, tests_only


def _replay_range(
    repo: Path,
    range_expr: str,
    out_dir: Path,
    post_merge: bool,
    coverage_db: Optional[str] = None,
) -> tuple[str, str, list[str], str, dict, bool]:
    """Replay the cumulative diff of a git range as a single CBTS run.

    The range's tip commit supplies the tree CBTS reads; the cumulative
    `git diff` over the range supplies changed_files + diffs. This mirrors
    how a real PR is evaluated (whole-PR diff, not commit-by-commit).
    """
    base, tip, diff_arg = _split_range(range_expr)
    tip_sha = _git(repo, "rev-parse", tip).stdout.strip()
    base_sha = _git(repo, "rev-parse", base, check=False).stdout.strip()
    subject = _git(repo, "log", "-1", "--pretty=%s", tip_sha).stdout.strip()
    files = _list_changed_files_range(repo, diff_arg)
    tests_only = _is_tests_only(files)
    base_disp = base_sha[:8] or base
    label = f"range-{base_disp}-{tip_sha[:8]}"
    pr_url = f"range {range_expr} (base={base_disp}, tip={tip_sha[:8]})"
    pr_dir = _prep_pr_dir(out_dir, label)
    diffs = {f: _file_diff_range(repo, diff_arg, f) for f in files}
    result = _cbts_for_snapshot(repo, tip_sha, files, diffs, post_merge, pr_dir, coverage_db)
    (pr_dir / "summary.txt").write_text(
        _fmt_summary(pr_url, tip_sha, subject, files, result, post_merge, tests_only)
    )
    return label, pr_url, files, subject, result, tests_only


def _write_index(
    out_dir: Path,
    rows: list[tuple[str, str, list[str], str, dict, bool]],
    ref: str,
    window: int,
    filter_mode: str,
    post_merge: bool,
    range_expr: Optional[str] = None,
) -> None:
    counts: dict[Optional[str], int] = {}
    compatibility_counts: dict[str, int] = {}
    decline_counts: dict[str, int] = {}
    for _, _, _, _, result, _ in rows:
        scope = result.get("scope") if "_error" not in result else "ERROR"
        counts[scope] = counts.get(scope, 0) + 1
        compatibility = result.get("coverage_compatibility") or "not_attempted"
        compatibility_counts[compatibility] = compatibility_counts.get(compatibility, 0) + 1
        category = result.get("coverage_decline_category") or "none"
        decline_counts[category] = decline_counts.get(category, 0) + 1

    trigger = "/bot run --post-merge" if post_merge else "/bot run"
    if range_expr:
        source_line = (
            f"Range: `{range_expr}` (cumulative diff), simulated as "
            f"`{trigger}` (post_merge={post_merge})."
        )
        detail_line = "Replayed as a single cumulative CBTS run."
    else:
        source_line = (
            f"Source ref: `{ref}` (last {window} commits), simulated as "
            f"`{trigger}` (post_merge={post_merge})."
        )
        detail_line = f"Filter: `{filter_mode}` — replayed commits: **{len(rows)}**"
    lines = [
        "# CBTS dry-run results",
        "",
        source_line,
        detail_line,
        "",
        "| Label | Scope | Stages | YAMLs | Sanity | Perf | Files | PR | Subject |",
        "|---|---|---|---|---|---|---|---|---|",
    ]

    def _sort_key(row):
        label = row[0]
        if label.startswith("pr-") and label[3:].isdigit():
            return (0, int(label[3:]))
        return (1, label)

    for label, pr_url, files, subject, result, _ in sorted(rows, key=_sort_key):
        lines.append(_index_row(label, pr_url, files, subject, result))
    lines += ["", "## Scope distribution", ""]
    for scope, n in sorted(counts.items(), key=lambda kv: -kv[1]):
        lines.append(f"- {scope or 'None (fallback)'}: {n}")
    lines += ["", "## Coverage compatibility distribution", ""]
    for compatibility, n in sorted(compatibility_counts.items(), key=lambda kv: -kv[1]):
        lines.append(f"- {compatibility}: {n}")
    lines += ["", "## Coverage decline distribution", ""]
    for category, n in sorted(decline_counts.items(), key=lambda kv: -kv[1]):
        lines.append(f"- {category}: {n}")
    (out_dir / "INDEX.md").write_text("\n".join(lines) + "\n")


def _positive_int(ctx, param, value):
    if value is None:
        return None
    if value <= 0:
        raise click.BadParameter(f"expected positive integer (>= 1), got {value}")
    return value


@click.command("dryrun", context_settings={"help_option_names": ["-h", "--help"]})
@click.option("--ref", default="upstream/main", help="git ref to walk (default: upstream/main)")
@click.option(
    "--window",
    type=int,
    default=500,
    callback=_positive_int,
    help="commits back from --ref, must be >= 1 (default: 500)",
)
@click.option(
    "--filter",
    "filter_mode",
    type=click.Choice(["tests-only", "all"]),
    default="tests-only",
    help="commit filter (default: tests-only)",
)
@click.option(
    "--limit",
    type=int,
    default=None,
    callback=_positive_int,
    help="cap commits after filter, must be >= 1 (default: no cap)",
)
@click.option(
    "--sha",
    "shas_opt",
    multiple=True,
    help="replay specific SHA (repeatable; ignores --ref/--window/--filter)",
)
@click.option(
    "--range",
    "range_expr",
    default=None,
    help="replay the CUMULATIVE diff of a git range as a single CBTS run "
    "(e.g. 'main..HEAD', 'origin/main...HEAD', or a bare SHA); "
    "ignores --ref/--window/--filter/--sha/--limit",
)
@click.option("--post-merge", "post_merge", is_flag=True, help="set post_merge=True")
@click.option(
    "--coverage-db",
    default=None,
    help="path to cbts_touchmap.sqlite; enables the coverage tier (Tier 2) in `cbts.command main`",
)
@click.option("--out", default="cbts_dryrun", help="output directory (default: cbts_dryrun)")
@click.option(
    "--repo-root",
    default=str(DEFAULT_REPO_ROOT),
    help=f"TRT-LLM repo root (default: {DEFAULT_REPO_ROOT})",
)
@click.option("--keep-stale", is_flag=True, help="don't wipe existing pr-*/sha-* dirs in --out")
def main(
    ref,
    window,
    filter_mode,
    limit,
    shas_opt,
    range_expr,
    post_merge,
    coverage_db,
    out,
    repo_root,
    keep_stale,
):
    """CBTS dry-run debug tool.

    Replays CBTS over historical commits and writes per-PR artifacts (summary
    + filtered test-db YAMLs) plus a top-level INDEX.md, so the rule set can
    be inspected without firing real CI.
    """
    sys.exit(
        _run(
            ref,
            window,
            filter_mode,
            limit,
            list(shas_opt),
            range_expr,
            post_merge,
            coverage_db,
            out,
            repo_root,
            keep_stale,
        )
    )


def _run(
    ref,
    window,
    filter_mode,
    limit,
    shas_arg,
    range_expr,
    post_merge,
    coverage_db,
    out,
    repo_root,
    keep_stale,
) -> int:
    repo = Path(repo_root).resolve()
    if not (repo / GROOVY_REL).exists():
        print(f"error: --repo-root does not look like a TRT-LLM checkout: {repo}", file=sys.stderr)
        return 2

    # Coverage tier is opt-in: it needs a separately downloaded touch DB.
    if coverage_db:
        print(f"coverage tier ON (merged with rules) via {coverage_db}", file=sys.stderr)
    else:
        print(
            "coverage tier OFF (rules only). To include coverage-based selection, download the "
            "post-merge cbts_pystart_report.tar.gz (.../L0_PostMerge/cbts-coverage/), extract "
            "cbts_touchmap.sqlite, and pass --coverage-db <path>.",
            file=sys.stderr,
        )

    # Drop stale worktree metadata from interrupted prior runs so
    # `git worktree add` doesn't trip on dangling entries.
    _git(repo, "worktree", "prune", check=False)

    out_dir = Path(out)
    if not out_dir.is_absolute():
        out_dir = (Path.cwd() / out_dir).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    if not keep_stale:
        for old in out_dir.iterdir():
            if old.is_dir() and old.name.startswith(("pr-", "sha-", "range-")):
                shutil.rmtree(old)

    rows: list[tuple[str, str, list[str], str, dict, bool]] = []
    if range_expr:
        print(f"Replaying cumulative range: {range_expr}", file=sys.stderr)
        try:
            row = _replay_range(repo, range_expr, out_dir, post_merge, coverage_db)
        except subprocess.CalledProcessError as e:
            print(f"git error: {e.stderr.strip()}", file=sys.stderr)
            return 1
        rows.append(row)
        label, _, _, _, result, _ = row
        scope = result.get("scope", "ERROR") if "_error" not in result else "ERROR"
        print(f"  {label}: {scope}", file=sys.stderr)
    else:
        if shas_arg:
            shas = shas_arg
            print(f"Replaying {len(shas)} explicit SHA(s)", file=sys.stderr)
        else:
            all_shas = _walk_commits(repo, ref, window)
            if filter_mode == "tests-only":
                shas = [s for s in all_shas if _is_tests_only(_list_changed_files(repo, s))]
            else:
                shas = all_shas
            if limit is not None:
                shas = shas[:limit]
            suffix = f", limit={limit}" if limit else ""
            print(
                f"Window: last {window} commits on {ref} → "
                f"{len(shas)} commits after filter={filter_mode}{suffix}",
                file=sys.stderr,
            )
        for sha in shas:
            try:
                row = _replay_one(repo, sha, out_dir, post_merge, coverage_db)
            except subprocess.CalledProcessError as e:
                print(f"  {sha[:8]}: git error: {e.stderr.strip()}", file=sys.stderr)
                continue
            rows.append(row)
            label, _, _, _, result, _ = row
            scope = result.get("scope", "ERROR") if "_error" not in result else "ERROR"
            print(f"  {label}: {scope}", file=sys.stderr)

    _write_index(
        out_dir,
        rows,
        ref,
        window,
        filter_mode,
        post_merge,
        range_expr=range_expr,
    )

    counts: dict[Optional[str], int] = {}
    for _, _, _, _, result, _ in rows:
        scope = result.get("scope") if "_error" not in result else "ERROR"
        counts[scope] = counts.get(scope, 0) + 1
    print(f"\nDone. Output: {out_dir}", file=sys.stderr)
    print(f"Scopes: {dict(sorted(counts.items(), key=lambda kv: -kv[1]))}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    main()
